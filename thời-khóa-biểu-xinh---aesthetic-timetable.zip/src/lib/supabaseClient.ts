import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { TimetableEntry, TimetableMeta, SupabaseConfig, WorkspaceId } from '../types';

const STORAGE_ENTRIES_KEY = 'aesthetic_timetable_entries_v1';
const STORAGE_META_KEY = 'aesthetic_timetable_meta_v1';
const STORAGE_SUPABASE_CONFIG_KEY = 'aesthetic_supabase_config_v1';

export const DEFAULT_SQL_SCHEMA = `-- =========================================================
-- BƯỚC 1: TẠO BẢNG DỮ LIỆU THỜI KHÓA BIỂU TRÊN SUPABASE (SQL EDITOR)
-- Hỗ trợ 2 Workspace độc lập ('lan_vy' & 'kim_anh') + Đồng bộ chủ động (Sync on Demand)
-- Sao chép toàn bộ đoạn mã này và dán vào Supabase -> SQL Editor -> Run
-- =========================================================

-- 1. Bảng lưu trữ từng tiết học với cột workspace_id ('lan_vy' hoặc 'kim_anh')
CREATE TABLE IF NOT EXISTS public.timetable_entries (
    id TEXT PRIMARY KEY,
    workspace_id VARCHAR(50) NOT NULL DEFAULT 'lan_vy', -- 'lan_vy' hoặc 'kim_anh'
    day VARCHAR(10) NOT NULL,                           -- 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'
    period_id VARCHAR(20) NOT NULL,                     -- 'm1', 'm2', ..., 'a1', 'a2', ..., 'e1', 'e2'
    subject TEXT NOT NULL,                              -- Tên môn học (Vd: Toán cao cấp, Tiếng Anh)
    room TEXT,                                          -- Phòng học hoặc link học trực tuyến
    teacher TEXT,                                       -- Tên giáo viên / giảng viên
    notes TEXT,                                         -- Ghi chú, bài tập về nhà
    color_theme VARCHAR(30) DEFAULT 'pink',            -- Màu sắc ô ('pink', 'sage', 'lavender', 'peach', 'amber', 'sky', 'mint', 'rose')
    icon VARCHAR(20) DEFAULT '🌸',                      -- Sticker emoji dễ thương
    status VARCHAR(20) DEFAULT 'todo',                  -- 'todo', 'in_progress', 'done'
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tạo index để lọc theo workspace_id cực nhanh
CREATE INDEX IF NOT EXISTS idx_entries_workspace ON public.timetable_entries(workspace_id);

-- [LỆNH NÂNG CẤP / DI TRÚ CHO BẢNG CŨ ĐÃ TẠO TỪ TRƯỚC]:
ALTER TABLE public.timetable_entries ADD COLUMN IF NOT EXISTS workspace_id VARCHAR(50) NOT NULL DEFAULT 'lan_vy';

-- 2. Bảng lưu thông tin tiêu đề và cấu hình riêng cho từng Workspace
CREATE TABLE IF NOT EXISTS public.timetable_meta (
    id VARCHAR(50) PRIMARY KEY,                         -- 'lan_vy' hoặc 'kim_anh'
    workspace_id VARCHAR(50) DEFAULT 'lan_vy',
    title TEXT NOT NULL DEFAULT 'Thời Khóa Biểu Xinh 🌷',
    subtitle TEXT DEFAULT 'Mỗi ngày là một bước tiến nhỏ dịu dàng ✨',
    owner_name TEXT DEFAULT 'Lan Vy',
    academic_year TEXT DEFAULT 'Học kỳ 1 - 2026',
    theme_id VARCHAR(50) DEFAULT 'peach_dream',
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- [LỆNH NÂNG CẤP CHO BẢNG META CŨ NẾU CẦN]:
ALTER TABLE public.timetable_meta ADD COLUMN IF NOT EXISTS workspace_id VARCHAR(50) DEFAULT 'lan_vy';

-- 3. Cấu hình quyền truy cập công khai (Row Level Security - RLS)
ALTER TABLE public.timetable_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.timetable_meta ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public access timetable_entries" ON public.timetable_entries;
CREATE POLICY "Public access timetable_entries"
ON public.timetable_entries
FOR ALL
USING (true)
WITH CHECK (true);

DROP POLICY IF EXISTS "Public access timetable_meta" ON public.timetable_meta;
CREATE POLICY "Public access timetable_meta"
ON public.timetable_meta
FOR ALL
USING (true)
WITH CHECK (true);

-- 4. Bật Realtime để đồng bộ tức thì 2 chiều giữa các thiết bị
ALTER PUBLICATION supabase_realtime ADD TABLE public.timetable_entries;
ALTER PUBLICATION supabase_realtime ADD TABLE public.timetable_meta;
`;

// Read environment variables (injected by Vercel / Vite .env)
const metaEnv = (import.meta as unknown as { env?: Record<string, string | undefined> })?.env || {};
const ENV_SUPABASE_URL = metaEnv.VITE_SUPABASE_URL?.trim() || '';
const ENV_SUPABASE_ANON_KEY = metaEnv.VITE_SUPABASE_ANON_KEY?.trim() || '';

export function getStoredSupabaseConfig(): SupabaseConfig {
  try {
    const raw = localStorage.getItem(STORAGE_SUPABASE_CONFIG_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.warn('Failed to parse stored Supabase config:', e);
  }
  return {
    url: '',
    anonKey: '',
    tableName: 'timetable_entries',
    connected: false,
  };
}

/**
 * Returns initial Supabase configuration.
 * Prioritizes Vercel / .env environment variables, then falls back to localStorage.
 */
export function getInitialSupabaseConfig(): SupabaseConfig {
  const stored = getStoredSupabaseConfig();
  const effectiveUrl = ENV_SUPABASE_URL || stored.url || '';
  const effectiveAnonKey = ENV_SUPABASE_ANON_KEY || stored.anonKey || '';
  const isConnected = Boolean(effectiveUrl && effectiveAnonKey);

  return {
    url: effectiveUrl,
    anonKey: effectiveAnonKey,
    tableName: stored.tableName || 'timetable_entries',
    connected: isConnected,
    lastSyncedAt: stored.lastSyncedAt,
    isFromEnv: Boolean(ENV_SUPABASE_URL && ENV_SUPABASE_ANON_KEY),
  };
}

export function saveStoredSupabaseConfig(config: SupabaseConfig): void {
  try {
    localStorage.setItem(STORAGE_SUPABASE_CONFIG_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save Supabase config to localStorage:', e);
  }
}

export function getStoredLocalData(): { entries: TimetableEntry[] | null; meta: TimetableMeta | null } {
  try {
    const entriesRaw = localStorage.getItem(STORAGE_ENTRIES_KEY);
    const metaRaw = localStorage.getItem(STORAGE_META_KEY);
    return {
      entries: entriesRaw ? JSON.parse(entriesRaw) : null,
      meta: metaRaw ? JSON.parse(metaRaw) : null,
    };
  } catch (e) {
    console.error('Failed to read from localStorage:', e);
    return { entries: null, meta: null };
  }
}

export function saveStoredLocalData(entries: TimetableEntry[], meta: TimetableMeta): void {
  try {
    localStorage.setItem(STORAGE_ENTRIES_KEY, JSON.stringify(entries));
    localStorage.setItem(STORAGE_META_KEY, JSON.stringify(meta));
  } catch (e) {
    console.error('Failed to save to localStorage:', e);
  }
}

let supabaseInstance: SupabaseClient | null = null;
let currentConfigKey = '';

export function getSupabaseClient(config: SupabaseConfig): SupabaseClient | null {
  if (!config.url || !config.anonKey) return null;
  const key = `${config.url.trim()}::${config.anonKey.trim()}`;
  if (supabaseInstance && currentConfigKey === key) {
    return supabaseInstance;
  }
  try {
    supabaseInstance = createClient(config.url.trim(), config.anonKey.trim(), {
      auth: { persistSession: false },
    });
    currentConfigKey = key;
    return supabaseInstance;
  } catch (e) {
    console.error('Failed to init Supabase client:', e);
    return null;
  }
}

export async function testSupabaseConnection(config: SupabaseConfig): Promise<{ success: boolean; message: string; tableReady?: boolean }> {
  const client = getSupabaseClient(config);
  if (!client) {
    return { success: false, message: 'Vui lòng điền đủ Supabase Project URL và Anon Key.' };
  }

  try {
    const { error } = await client
      .from(config.tableName || 'timetable_entries')
      .select('id')
      .limit(1);

    if (error) {
      if (error.code === '42P01' || error.message.includes('relation') || error.message.includes('does not exist')) {
        return {
          success: true,
          tableReady: false,
          message: 'Đã kết nối thành công tới Supabase! Tuy nhiên bảng "timetable_entries" chưa được tạo. Vui lòng chạy đoạn mã SQL ở Bước 2.',
        };
      }
      return { success: false, message: `Lỗi Supabase: ${error.message} (${error.code || ''})` };
    }

    return {
      success: true,
      tableReady: true,
      message: 'Kết nối Supabase thành công tuyệt vời! Bảng dữ liệu đã sẵn sàng hoạt động.',
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    return { success: false, message: `Lỗi kết nối: ${msg}` };
  }
}

export async function syncFromSupabase(
  config: SupabaseConfig,
  workspaceId?: WorkspaceId
): Promise<{ entries: TimetableEntry[]; meta?: TimetableMeta } | null> {
  const client = getSupabaseClient(config);
  if (!client) return null;

  try {
    const targetWs = workspaceId || 'lan_vy';

    // 1. Fetch entries (fetch all or specific workspace)
    let query = client.from(config.tableName || 'timetable_entries').select('*');
    if (workspaceId) {
      query = query.eq('workspace_id', workspaceId);
    }

    const { data: entriesData, error: entriesError } = await query;

    if (entriesError) {
      throw entriesError;
    }

    const mappedEntries: TimetableEntry[] = (entriesData || []).map((row: any) => ({
      id: row.id,
      workspaceId: (row.workspace_id === 'kim_anh' ? 'kim_anh' : 'lan_vy') as WorkspaceId,
      day: row.day,
      periodId: row.period_id,
      subject: row.subject,
      room: row.room || '',
      teacher: row.teacher || '',
      notes: row.notes || '',
      colorTheme: row.color_theme || 'pink',
      icon: row.icon || '🌸',
      status: row.status || 'todo',
      updatedAt: row.updated_at,
    }));

    // 2. Fetch meta for workspace (falls back to current_schedule for backward compatibility)
    let meta: TimetableMeta | undefined = undefined;
    let metaData: any = null;

    const { data: wsMetaData } = await client
      .from('timetable_meta')
      .select('*')
      .or(`id.eq.${targetWs},id.eq.current_schedule`)
      .limit(1)
      .maybeSingle();

    metaData = wsMetaData;

    if (metaData) {
      meta = {
        workspaceId: targetWs,
        title: metaData.title,
        subtitle: metaData.subtitle,
        ownerName: metaData.owner_name,
        academicYear: metaData.academic_year,
        themeId: metaData.theme_id,
        showBreaks: true,
        viewMode: 'full',
        selectedDailyDay: 'mon',
      };
    }

    return { entries: mappedEntries, meta };
  } catch (err) {
    console.error('Failed to sync from Supabase:', err);
    throw err;
  }
}

export async function syncToSupabase(
  config: SupabaseConfig,
  entries: TimetableEntry[],
  meta: TimetableMeta,
  workspaceId?: WorkspaceId
): Promise<boolean> {
  const client = getSupabaseClient(config);
  if (!client) return false;

  try {
    const tableName = config.tableName || 'timetable_entries';
    const targetWs = workspaceId || meta.workspaceId || 'lan_vy';

    // Only process entries for the specified workspace
    const wsEntries = entries.filter((e) => (e.workspaceId || 'lan_vy') === targetWs);

    // 1. Transform entries to DB schema
    const rows = wsEntries.map((entry) => ({
      id: entry.id,
      workspace_id: targetWs,
      day: entry.day,
      period_id: entry.periodId,
      subject: entry.subject,
      room: entry.room || '',
      teacher: entry.teacher || '',
      notes: entry.notes || '',
      color_theme: entry.colorTheme || 'pink',
      icon: entry.icon || '🌸',
      status: entry.status || 'todo',
      updated_at: new Date().toISOString(),
    }));

    // If there are entries to upsert
    if (rows.length > 0) {
      const { error: entriesError } = await client
        .from(tableName)
        .upsert(rows, { onConflict: 'id' });

      if (entriesError) throw entriesError;
    }

    // 2. Remove entries in DB for this workspace that have been deleted locally
    const currentIds = new Set(wsEntries.map((e) => e.id));
    const { data: existingRows } = await client
      .from(tableName)
      .select('id')
      .eq('workspace_id', targetWs);

    if (existingRows && existingRows.length > 0) {
      const idsToDelete = existingRows
        .map((r: any) => r.id)
        .filter((id: string) => !currentIds.has(id));

      if (idsToDelete.length > 0) {
        await client.from(tableName).delete().in('id', idsToDelete);
      }
    }

    // 3. Upsert meta for this workspace
    await client.from('timetable_meta').upsert(
      {
        id: targetWs,
        workspace_id: targetWs,
        title: meta.title,
        subtitle: meta.subtitle,
        owner_name: meta.ownerName,
        academic_year: meta.academicYear,
        theme_id: meta.themeId,
        updated_at: new Date().toISOString(),
      },
      { onConflict: 'id' }
    );

    return true;
  } catch (err) {
    console.error('Failed to sync to Supabase:', err);
    throw err;
  }
}

/**
 * Upsert a single entry to Supabase in real-time
 */
export async function upsertEntryToSupabase(
  config: SupabaseConfig,
  entry: TimetableEntry
): Promise<boolean> {
  const client = getSupabaseClient(config);
  if (!client) return false;

  try {
    const row = {
      id: entry.id,
      workspace_id: entry.workspaceId || 'lan_vy',
      day: entry.day,
      period_id: entry.periodId,
      subject: entry.subject,
      room: entry.room || '',
      teacher: entry.teacher || '',
      notes: entry.notes || '',
      color_theme: entry.colorTheme || 'pink',
      icon: entry.icon || '🌸',
      status: entry.status || 'todo',
      updated_at: new Date().toISOString(),
    };

    const { error } = await client
      .from(config.tableName || 'timetable_entries')
      .upsert([row], { onConflict: 'id' });

    if (error) throw error;
    return true;
  } catch (err) {
    console.error('Failed to upsert entry to Supabase:', err);
    return false;
  }
}

/**
 * Delete a single entry from Supabase in real-time
 */
export async function deleteFromSupabase(
  config: SupabaseConfig,
  entryId: string
): Promise<boolean> {
  const client = getSupabaseClient(config);
  if (!client) return false;

  try {
    const { error } = await client
      .from(config.tableName || 'timetable_entries')
      .delete()
      .eq('id', entryId);

    if (error) throw error;
    return true;
  } catch (err) {
    console.error('Failed to delete entry from Supabase:', err);
    return false;
  }
}

/**
 * Sync timetable meta (title, theme, owner, academic year) to Supabase
 */
export async function syncMetaToSupabase(
  config: SupabaseConfig,
  meta: TimetableMeta,
  workspaceId?: WorkspaceId
): Promise<boolean> {
  const client = getSupabaseClient(config);
  if (!client) return false;

  const targetWs = workspaceId || meta.workspaceId || 'lan_vy';

  try {
    const { error } = await client.from('timetable_meta').upsert(
      {
        id: targetWs,
        workspace_id: targetWs,
        title: meta.title,
        subtitle: meta.subtitle,
        owner_name: meta.ownerName,
        academic_year: meta.academicYear,
        theme_id: meta.themeId,
        updated_at: new Date().toISOString(),
      },
      { onConflict: 'id' }
    );

    if (error) throw error;
    return true;
  } catch (err) {
    console.error('Failed to sync meta to Supabase:', err);
    return false;
  }
}

/**
 * Sync on demand: Copy a single entry from one workspace to another
 */
export async function copyEntryToWorkspace(
  config: SupabaseConfig,
  sourceEntry: TimetableEntry,
  targetWorkspaceId: WorkspaceId
): Promise<TimetableEntry> {
  const newEntry: TimetableEntry = {
    ...sourceEntry,
    id: `${targetWorkspaceId}_${sourceEntry.day}_${sourceEntry.periodId}`,
    workspaceId: targetWorkspaceId,
    updatedAt: new Date().toISOString(),
  };

  const client = getSupabaseClient(config);
  if (client) {
    try {
      await client.from(config.tableName || 'timetable_entries').upsert(
        [
          {
            id: newEntry.id,
            workspace_id: newEntry.workspaceId,
            day: newEntry.day,
            period_id: newEntry.periodId,
            subject: newEntry.subject,
            room: newEntry.room || '',
            teacher: newEntry.teacher || '',
            notes: newEntry.notes || '',
            color_theme: newEntry.colorTheme || 'pink',
            icon: newEntry.icon || '🌸',
            status: newEntry.status || 'todo',
            updated_at: newEntry.updatedAt,
          },
        ],
        { onConflict: 'id' }
      );
    } catch (err) {
      console.warn('Could not immediately push copied entry to Supabase:', err);
    }
  }

  return newEntry;
}

/**
 * Sync on demand: Copy multiple entries (Row/Day or Full schedule) to target workspace
 */
export async function copyMultipleEntriesToWorkspace(
  config: SupabaseConfig,
  sourceEntries: TimetableEntry[],
  targetWorkspaceId: WorkspaceId
): Promise<TimetableEntry[]> {
  const newEntries: TimetableEntry[] = sourceEntries.map((e) => ({
    ...e,
    id: `${targetWorkspaceId}_${e.day}_${e.periodId}`,
    workspaceId: targetWorkspaceId,
    updatedAt: new Date().toISOString(),
  }));

  const client = getSupabaseClient(config);
  if (client && newEntries.length > 0) {
    try {
      const rows = newEntries.map((e) => ({
        id: e.id,
        workspace_id: e.workspaceId,
        day: e.day,
        period_id: e.periodId,
        subject: e.subject,
        room: e.room || '',
        teacher: e.teacher || '',
        notes: e.notes || '',
        color_theme: e.colorTheme || 'pink',
        icon: e.icon || '🌸',
        status: e.status || 'todo',
        updated_at: e.updatedAt,
      }));

      await client
        .from(config.tableName || 'timetable_entries')
        .upsert(rows, { onConflict: 'id' });
    } catch (err) {
      console.warn('Could not immediately push copied entries to Supabase:', err);
    }
  }

  return newEntries;
}
