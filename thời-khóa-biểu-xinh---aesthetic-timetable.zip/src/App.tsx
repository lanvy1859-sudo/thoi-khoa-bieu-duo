import React, { useState, useEffect } from 'react';
import {
  TimetableEntry,
  TimetableMeta,
  SupabaseConfig,
  DayOfWeek,
  SyncStatusState,
  WorkspaceId,
} from './types';
import { THEMES, SAMPLE_ENTRIES, PERIODS, DAYS_OF_WEEK, WORKSPACES } from './constants/scheduleConfig';
import {
  getStoredLocalData,
  saveStoredLocalData,
  getInitialSupabaseConfig,
  saveStoredSupabaseConfig,
  syncToSupabase,
  syncFromSupabase,
  upsertEntryToSupabase,
  deleteFromSupabase,
  syncMetaToSupabase,
  getSupabaseClient,
  copyEntryToWorkspace,
  copyMultipleEntriesToWorkspace,
} from './lib/supabaseClient';
import { Navbar } from './components/Navbar';
import { TimetableGrid } from './components/TimetableGrid';
import { DailyView } from './components/DailyView';
import { EditEntryModal } from './components/EditEntryModal';
import { SupabaseGuideModal } from './components/SupabaseGuideModal';
import { Heart, Sparkles, Database, Coffee, BookOpen, Cloud, RefreshCw, CheckCircle2, Info } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function App() {
  // Initialize local data
  const stored = getStoredLocalData();
  const [entries, setEntries] = useState<TimetableEntry[]>(() => {
    return stored.entries && stored.entries.length > 0 ? stored.entries : SAMPLE_ENTRIES;
  });

  const [meta, setMeta] = useState<TimetableMeta>(() => {
    return (
      stored.meta || {
        title: 'Thời Khóa Biểu Xinh 🌷',
        subtitle: 'Lịch học & cảm hứng mỗi ngày dịu dàng ✨',
        ownerName: 'Vy Xinh',
        academicYear: 'Học kỳ 1 - 2026',
        themeId: 'peach_dream',
        showBreaks: true,
        viewMode: 'full',
        selectedDailyDay: 'mon',
      }
    );
  });

  // Active Workspace: 'lan_vy' or 'kim_anh'
  const [currentWorkspace, setCurrentWorkspace] = useState<WorkspaceId>(() => {
    const saved = localStorage.getItem('aesthetic_timetable_workspace') as WorkspaceId;
    return saved === 'kim_anh' ? 'kim_anh' : 'lan_vy';
  });

  // Read-only logic: When viewing Kim Ánh's workspace, enable Read-only mode & show sync buttons
  const isReadOnly = currentWorkspace === 'kim_anh';

  // Toast notification state
  const [toast, setToast] = useState<{ message: string; icon?: string } | null>(null);
  const showToast = (message: string, icon = '🌸') => {
    setToast({ message, icon });
    setTimeout(() => {
      setToast(null);
    }, 4500);
  };

  const [supabaseConfig, setSupabaseConfig] = useState<SupabaseConfig>(() => {
    return getInitialSupabaseConfig();
  });

  const [syncStatus, setSyncStatus] = useState<SyncStatusState>(() => {
    const initCfg = getInitialSupabaseConfig();
    return initCfg.connected ? 'syncing' : 'local';
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<Partial<TimetableEntry> | null>(null);
  const [modalDefaultDay, setModalDefaultDay] = useState<DayOfWeek>('mon');
  const [modalDefaultPeriodId, setModalDefaultPeriodId] = useState<string>('m1');
  const [isSupabaseModalOpen, setIsSupabaseModalOpen] = useState(false);

  // Auto-save to localStorage whenever entries or meta change
  useEffect(() => {
    saveStoredLocalData(entries, meta);
  }, [entries, meta]);

  // Initial fetch from Supabase Cloud on app start (cross-device & Vercel sync)
  useEffect(() => {
    if (!supabaseConfig.url || !supabaseConfig.anonKey) {
      setSyncStatus('local');
      return;
    }

    let isSubscribed = true;
    setSyncStatus('syncing');

    syncFromSupabase(supabaseConfig)
      .then((res) => {
        if (!isSubscribed) return;
        if (res && res.entries && res.entries.length > 0) {
          setEntries(res.entries);
          if (res.meta) {
            setMeta((prev) => ({ ...prev, ...res.meta }));
          }
          setSyncStatus('synced');
          setSupabaseConfig((prev) => ({
            ...prev,
            connected: true,
            lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
          }));
        } else if (res && res.entries && res.entries.length === 0 && entries.length > 0) {
          syncToSupabase(supabaseConfig, entries, meta)
            .then(() => {
              if (isSubscribed) {
                setSyncStatus('synced');
                setSupabaseConfig((prev) => ({
                  ...prev,
                  connected: true,
                  lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
                }));
              }
            })
            .catch(() => {
              if (isSubscribed) setSyncStatus('synced');
            });
        } else {
          setSyncStatus('synced');
        }
      })
      .catch((err) => {
        console.warn('Could not auto-fetch from Supabase Cloud, continuing with local data:', err);
        if (isSubscribed) setSyncStatus('error');
      });

    return () => {
      isSubscribed = false;
    };
  }, [supabaseConfig.url, supabaseConfig.anonKey]);

  // Supabase Realtime multi-device / multi-tab live subscription
  useEffect(() => {
    if (!supabaseConfig.url || !supabaseConfig.anonKey) return;
    const client = getSupabaseClient(supabaseConfig);
    if (!client) return;

    const tableName = supabaseConfig.tableName || 'timetable_entries';
    const channel = client
      .channel('timetable_live_sync_channel')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: tableName },
        () => {
          syncFromSupabase(supabaseConfig)
            .then((res) => {
              if (res) {
                setEntries(res.entries);
                if (res.meta) setMeta((prev) => ({ ...prev, ...res.meta }));
                setSyncStatus('synced');
              }
            })
            .catch(console.warn);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'timetable_meta' },
        () => {
          syncFromSupabase(supabaseConfig)
            .then((res) => {
              if (res && res.meta) {
                setMeta((prev) => ({ ...prev, ...res.meta }));
                setSyncStatus('synced');
              }
            })
            .catch(console.warn);
        }
      )
      .subscribe();

    return () => {
      client.removeChannel(channel);
    };
  }, [supabaseConfig.url, supabaseConfig.anonKey, supabaseConfig.tableName]);

  // Current active theme
  const currentTheme = THEMES.find((t) => t.id === meta.themeId) || THEMES[0];

  // Workspace Switcher
  const handleSelectWorkspace = (ws: WorkspaceId) => {
    setCurrentWorkspace(ws);
    localStorage.setItem('aesthetic_timetable_workspace', ws);
    const wsProfile = WORKSPACES[ws];
    showToast(`Đã chuyển sang không gian: ${wsProfile.name}`, wsProfile.avatar);
  };

  // Filter entries according to active workspace
  const displayedEntries = entries.filter((e) => (e.workspaceId || 'lan_vy') === currentWorkspace);

  // Handlers for Entries
  const handleAddEntry = (day: DayOfWeek, periodId: string) => {
    if (isReadOnly) return;
    setEditingEntry(null);
    setModalDefaultDay(day);
    setModalDefaultPeriodId(periodId);
    setIsEditModalOpen(true);
  };

  const handleEditEntry = (entry: TimetableEntry) => {
    if (isReadOnly) return;
    setEditingEntry(entry);
    setModalDefaultDay(entry.day);
    setModalDefaultPeriodId(entry.periodId);
    setIsEditModalOpen(true);
  };

  const handleSaveEntry = (newEntry: TimetableEntry) => {
    const entryWithWs: TimetableEntry = {
      ...newEntry,
      workspaceId: currentWorkspace,
    };

    const exists = entries.some((e) => e.id === entryWithWs.id);
    let updatedEntries: TimetableEntry[];

    if (exists) {
      updatedEntries = entries.map((e) => (e.id === entryWithWs.id ? entryWithWs : e));
    } else {
      const otherEntries = entries.filter(
        (e) =>
          !(
            (e.workspaceId || 'lan_vy') === currentWorkspace &&
            e.day === entryWithWs.day &&
            e.periodId === entryWithWs.periodId
          )
      );
      updatedEntries = [...otherEntries, entryWithWs];
    }

    setEntries(updatedEntries);

    // Auto-sync real-time to Supabase Cloud
    if (supabaseConfig.connected && supabaseConfig.url && supabaseConfig.anonKey) {
      setSyncStatus('syncing');
      upsertEntryToSupabase(supabaseConfig, entryWithWs)
        .then(() => {
          setSyncStatus('synced');
          setSupabaseConfig((prev) => ({
            ...prev,
            lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
          }));
        })
        .catch((err) => {
          console.warn('Real-time Supabase save failed:', err);
          setSyncStatus('error');
        });
    }
  };

  const handleDeleteEntry = (id: string) => {
    if (isReadOnly) return;
    const updated = entries.filter((e) => e.id !== id);
    setEntries(updated);

    if (supabaseConfig.connected && supabaseConfig.url && supabaseConfig.anonKey) {
      setSyncStatus('syncing');
      deleteFromSupabase(supabaseConfig, id)
        .then(() => {
          setSyncStatus('synced');
          setSupabaseConfig((prev) => ({
            ...prev,
            lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
          }));
        })
        .catch((err) => {
          console.warn('Real-time Supabase delete failed:', err);
          setSyncStatus('error');
        });
    }
  };

  const handleToggleStatus = (entry: TimetableEntry) => {
    if (isReadOnly) return;
    const nextStatus: 'todo' | 'done' = entry.status === 'done' ? 'todo' : 'done';
    const updatedItem: TimetableEntry = { ...entry, status: nextStatus, workspaceId: currentWorkspace };
    const updated = entries.map((e) => (e.id === entry.id ? updatedItem : e));
    setEntries(updated);

    if (nextStatus === 'done') {
      confetti({
        particleCount: 35,
        spread: 50,
        origin: { y: 0.7 },
      });
    }

    if (supabaseConfig.connected && supabaseConfig.url && supabaseConfig.anonKey) {
      setSyncStatus('syncing');
      upsertEntryToSupabase(supabaseConfig, updatedItem)
        .then(() => {
          setSyncStatus('synced');
          setSupabaseConfig((prev) => ({
            ...prev,
            lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
          }));
        })
        .catch((err) => {
          console.warn('Real-time Supabase status sync failed:', err);
          setSyncStatus('error');
        });
    }
  };

  /* ============================================================
     SYNC ON DEMAND LOGIC (Copy from Kim Ánh -> Lan Vy)
     ============================================================ */
  const targetUserWorkspace: WorkspaceId = 'lan_vy';

  // 1. Cell Sync: Copy a single period cell
  const handleSyncCell = async (sourceEntry: TimetableEntry) => {
    const copied: TimetableEntry = {
      ...sourceEntry,
      id: `${targetUserWorkspace}_${sourceEntry.day}_${sourceEntry.periodId}`,
      workspaceId: targetUserWorkspace,
      status: 'todo',
      updatedAt: new Date().toISOString(),
    };

    setEntries((prev) => {
      const filtered = prev.filter(
        (e) =>
          !(
            (e.workspaceId || 'lan_vy') === targetUserWorkspace &&
            e.day === sourceEntry.day &&
            e.periodId === sourceEntry.periodId
          )
      );
      return [...filtered, copied];
    });

    confetti({ particleCount: 40, spread: 60, origin: { y: 0.6 } });
    showToast(`Đã chép môn "${sourceEntry.subject}" sang lịch của Vy! 🌸`, '✨');

    if (supabaseConfig.connected) {
      setSyncStatus('syncing');
      await copyEntryToWorkspace(supabaseConfig, sourceEntry, targetUserWorkspace);
      setSyncStatus('synced');
    }
  };

  // 2. Day Sync: Copy entire day (Column Sync)
  const handleSyncDay = async (day: DayOfWeek) => {
    const dayObj = DAYS_OF_WEEK.find((d) => d.id === day);
    const dayEntries = displayedEntries.filter((e) => e.day === day);

    if (dayEntries.length === 0) {
      showToast(`Không có tiết nào trong ${dayObj?.name || day} của Ánh để chép.`, 'ℹ️');
      return;
    }

    const copiedEntries: TimetableEntry[] = dayEntries.map((e) => ({
      ...e,
      id: `${targetUserWorkspace}_${e.day}_${e.periodId}`,
      workspaceId: targetUserWorkspace,
      status: 'todo',
      updatedAt: new Date().toISOString(),
    }));

    setEntries((prev) => {
      const filtered = prev.filter(
        (e) => !((e.workspaceId || 'lan_vy') === targetUserWorkspace && e.day === day)
      );
      return [...filtered, ...copiedEntries];
    });

    confetti({ particleCount: 65, spread: 80, origin: { y: 0.6 } });
    showToast(`Đã chép ${copiedEntries.length} tiết ${dayObj?.name} sang lịch của Vy! 🌷`, '📅');

    if (supabaseConfig.connected) {
      setSyncStatus('syncing');
      await copyMultipleEntriesToWorkspace(supabaseConfig, dayEntries, targetUserWorkspace);
      setSyncStatus('synced');
    }
  };

  // 3. Period Sync: Copy entire period row (Row Sync)
  const handleSyncPeriod = async (periodId: string) => {
    const periodObj = PERIODS.find((p) => p.id === periodId);
    const periodEntries = displayedEntries.filter((e) => e.periodId === periodId);

    if (periodEntries.length === 0) {
      showToast(`Không có tiết nào trong ${periodObj?.name || periodId} của Ánh để chép.`, 'ℹ️');
      return;
    }

    const copiedEntries: TimetableEntry[] = periodEntries.map((e) => ({
      ...e,
      id: `${targetUserWorkspace}_${e.day}_${e.periodId}`,
      workspaceId: targetUserWorkspace,
      status: 'todo',
      updatedAt: new Date().toISOString(),
    }));

    setEntries((prev) => {
      const filtered = prev.filter(
        (e) => !((e.workspaceId || 'lan_vy') === targetUserWorkspace && e.periodId === periodId)
      );
      return [...filtered, ...copiedEntries];
    });

    confetti({ particleCount: 60, spread: 75, origin: { y: 0.6 } });
    showToast(`Đã chép các tiết ${periodObj?.name} sang lịch của Vy! ✨`, '⏰');

    if (supabaseConfig.connected) {
      setSyncStatus('syncing');
      await copyMultipleEntriesToWorkspace(supabaseConfig, periodEntries, targetUserWorkspace);
      setSyncStatus('synced');
    }
  };

  // 4. Full Sync: Copy all entries from other workspace
  const handleSyncAllFromOther = async () => {
    const otherEntries = entries.filter((e) => (e.workspaceId || 'lan_vy') === 'kim_anh');

    if (otherEntries.length === 0) {
      showToast('Lịch của Kim Ánh hiện chưa có tiết học nào để chép.', 'ℹ️');
      return;
    }

    if (
      !window.confirm(
        `Bạn có chắc muốn chép toàn bộ ${otherEntries.length} tiết học từ Kim Ánh sang lịch của Vy không? Các tiết tương ứng sẽ được cập nhật.`
      )
    ) {
      return;
    }

    const copiedEntries: TimetableEntry[] = otherEntries.map((e) => ({
      ...e,
      id: `${targetUserWorkspace}_${e.day}_${e.periodId}`,
      workspaceId: targetUserWorkspace,
      status: 'todo',
      updatedAt: new Date().toISOString(),
    }));

    setEntries((prev) => {
      const existingVy = prev.filter((e) => (e.workspaceId || 'lan_vy') === targetUserWorkspace);
      const copiedKeys = new Set(copiedEntries.map((c) => `${c.day}_${c.periodId}`));
      const nonCollidingVy = existingVy.filter((v) => !copiedKeys.has(`${v.day}_${v.periodId}`));
      const nonVy = prev.filter((e) => (e.workspaceId || 'lan_vy') !== targetUserWorkspace);

      return [...nonVy, ...nonCollidingVy, ...copiedEntries];
    });

    confetti({ particleCount: 100, spread: 100, origin: { y: 0.5 } });
    showToast(`Đã chép toàn bộ ${copiedEntries.length} tiết học từ Kim Ánh sang Lan Vy! 💖`, '🌟');

    if (supabaseConfig.connected) {
      setSyncStatus('syncing');
      await copyMultipleEntriesToWorkspace(supabaseConfig, otherEntries, targetUserWorkspace);
      setSyncStatus('synced');
    }
  };

  const handleFillSampleData = () => {
    if (isReadOnly) return;
    if (
      displayedEntries.length > 0 &&
      !window.confirm('Bạn có muốn điền lại toàn bộ dữ liệu mẫu thiết kế xinh xắn không?')
    ) {
      return;
    }

    const sampleTagged = SAMPLE_ENTRIES.map((e) => ({
      ...e,
      id: `${currentWorkspace}_${e.day}_${e.periodId}`,
      workspaceId: currentWorkspace,
    }));

    setEntries((prev) => {
      const otherWs = prev.filter((e) => (e.workspaceId || 'lan_vy') !== currentWorkspace);
      return [...otherWs, ...sampleTagged];
    });

    confetti({
      particleCount: 70,
      spread: 80,
      origin: { y: 0.5 },
    });
    showToast('Đã điền thời khóa biểu mẫu thiết kế cực xinh!', '✨');

    if (supabaseConfig.connected && supabaseConfig.url && supabaseConfig.anonKey) {
      setSyncStatus('syncing');
      syncToSupabase(supabaseConfig, sampleTagged, meta, currentWorkspace)
        .then(() => setSyncStatus('synced'))
        .catch(() => setSyncStatus('error'));
    }
  };

  const handleResetData = () => {
    if (isReadOnly) return;
    if (window.confirm('Bạn có chắc muốn xóa tất cả tiết học trong không gian này không?')) {
      setEntries((prev) => prev.filter((e) => (e.workspaceId || 'lan_vy') !== currentWorkspace));
      showToast('Đã xóa trắng thời khóa biểu.', '🧹');

      if (supabaseConfig.connected && supabaseConfig.url && supabaseConfig.anonKey) {
        setSyncStatus('syncing');
        syncToSupabase(supabaseConfig, [], meta, currentWorkspace)
          .then(() => setSyncStatus('synced'))
          .catch(() => setSyncStatus('error'));
      }
    }
  };

  const handleUpdateMeta = (patch: Partial<TimetableMeta>) => {
    setMeta((prev) => {
      const next = { ...prev, ...patch };
      if (supabaseConfig.connected && supabaseConfig.url && supabaseConfig.anonKey) {
        syncMetaToSupabase(supabaseConfig, next, currentWorkspace).catch(console.warn);
      }
      return next;
    });
  };

  const handleSelectTheme = (themeId: string) => {
    setMeta((prev) => {
      const next = { ...prev, themeId };
      if (supabaseConfig.connected && supabaseConfig.url && supabaseConfig.anonKey) {
        syncMetaToSupabase(supabaseConfig, next, currentWorkspace).catch(console.warn);
      }
      return next;
    });
  };

  const handleSaveSupabaseConfig = (cfg: SupabaseConfig) => {
    setSupabaseConfig(cfg);
    saveStoredSupabaseConfig(cfg);
    if (cfg.connected) {
      setSyncStatus('synced');
    }
  };

  const handleSyncDataLoaded = (newEntries: TimetableEntry[], newMeta?: TimetableMeta) => {
    setEntries(newEntries);
    if (newMeta) {
      setMeta(newMeta);
    }
    setSyncStatus('synced');
  };

  const handlePrint = () => {
    window.print();
  };

  // Schedule statistics for currently displayed workspace
  const totalEntries = displayedEntries.length;
  const completedEntries = displayedEntries.filter((e) => e.status === 'done').length;

  return (
    <div
      id="aesthetic-timetable-app-root"
      className={`min-h-screen ${currentTheme.bgColor} transition-colors duration-300 p-3 sm:p-6 lg:p-8 flex flex-col justify-between`}
    >
      {/* Floating Sync Toast Notification */}
      {toast && (
        <div
          id="sync-toast-notification"
          className="fixed top-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 bg-white/95 backdrop-blur-md border border-pink-200 text-slate-800 rounded-2xl shadow-xl animate-bounce-subtle"
        >
          <span className="text-xl">{toast.icon || '🌸'}</span>
          <span className="text-xs sm:text-sm font-bold">{toast.message}</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto w-full space-y-6">
        {/* Printable Header (visible on paper/PDF export) */}
        <div className="hidden print-only text-center pb-4 border-b border-stone-300 mb-4">
          <h1 className="text-2xl font-bold">{meta.title}</h1>
          <p className="text-sm text-stone-600">{meta.subtitle}</p>
          <div className="flex justify-center gap-6 text-xs text-stone-500 mt-2">
            <span>Không gian: {WORKSPACES[currentWorkspace].name}</span>
            <span>Thứ 2 đến Chủ nhật</span>
            <span>Sáng: 5 tiết (07:00 - 11:15)</span>
            <span>Chiều: 13:30 - 17:00</span>
            <span>Tối: 17:15 - 20:30</span>
          </div>
        </div>

        {/* Navigation & Controls */}
        <Navbar
          meta={meta}
          onUpdateMeta={handleUpdateMeta}
          currentTheme={currentTheme}
          onSelectTheme={handleSelectTheme}
          supabaseConfig={supabaseConfig}
          syncStatus={syncStatus}
          onOpenSupabaseModal={() => setIsSupabaseModalOpen(true)}
          onFillSampleData={handleFillSampleData}
          onResetData={handleResetData}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onPrint={handlePrint}
          currentWorkspace={currentWorkspace}
          onSelectWorkspace={handleSelectWorkspace}
          onSyncAllFromOther={handleSyncAllFromOther}
          isReadOnly={isReadOnly}
        />

        {/* Quick Schedule Highlights Bar */}
        <div className="no-print flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-white/60 backdrop-blur-xs rounded-2xl border border-stone-200/70 text-xs text-slate-600">
          <div className="flex items-center gap-4 flex-wrap">
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2 h-2 rounded-full bg-pink-400" />
              Không gian <strong>{WORKSPACES[currentWorkspace].name}</strong>: <strong className="text-slate-800">{totalEntries}</strong> tiết
            </span>
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              Đã xong: <strong className="text-emerald-700">{completedEntries}</strong> tiết
            </span>
            <span className="hidden sm:inline text-stone-300">|</span>
            <span className="hidden sm:flex items-center gap-1 text-slate-500">
              <Coffee size={13} className="text-amber-500" />
              <span>Ra chơi 5p & 15p chuẩn quy định</span>
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* Sync Cloud Status Indicator */}
            {supabaseConfig.connected ? (
              <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200/80 px-2.5 py-1 rounded-xl">
                <Cloud size={13} className="text-emerald-600" />
                <span>
                  {syncStatus === 'syncing'
                    ? 'Đang lưu Cloud...'
                    : supabaseConfig.isFromEnv
                    ? 'Vercel Realtime Synced'
                    : 'Supabase DB Synced'}
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-xs text-slate-500 bg-stone-100 px-2.5 py-1 rounded-xl">
                <span>💾 Lưu bộ nhớ máy</span>
              </div>
            )}

            <button
              type="button"
              onClick={() => setIsSupabaseModalOpen(true)}
              className="text-slate-600 hover:text-emerald-700 flex items-center gap-1 text-xs font-semibold underline underline-offset-2 transition-colors"
            >
              <Database size={13} />
              <span>{supabaseConfig.connected ? 'Quản lý DB / Vercel' : 'Cấu hình Supabase & Vercel'}</span>
            </button>
          </div>
        </div>

        {/* Read-Only Notice Banner when viewing other person's schedule */}
        {isReadOnly && (
          <div className="no-print p-3.5 bg-amber-50/90 border border-amber-200 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-amber-900 shadow-xs">
            <div className="flex items-center gap-2">
              <Info size={16} className="text-amber-600 shrink-0" />
              <div>
                <strong>Bạn đang xem lịch của {WORKSPACES[currentWorkspace].name} (Chế độ chỉ xem)</strong>
                <p className="text-amber-700 text-[11px] mt-0.5">
                  Bấm nút <strong>"Chép sang lịch của tôi"</strong> trên bất kỳ ô tiết học nào hoặc trên đầu cột/hàng để sao chép sang lịch của Vy.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleSyncAllFromOther}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold shadow-xs transition-colors shrink-0"
            >
              Chép tất cả sang lịch của tôi
            </button>
          </div>
        )}

        {/* Main Content: Timetable Board or Daily View */}
        <main className="timetable-print-container">
          {meta.viewMode === 'daily' ? (
            <DailyView
              entries={displayedEntries}
              selectedDay={meta.selectedDailyDay}
              onSelectDay={(day) => handleUpdateMeta({ selectedDailyDay: day })}
              onAddEntry={handleAddEntry}
              onEditEntry={handleEditEntry}
              onToggleStatus={handleToggleStatus}
              theme={currentTheme}
              isReadOnly={isReadOnly}
              onSyncCell={handleSyncCell}
              onSyncDay={handleSyncDay}
            />
          ) : (
            <TimetableGrid
              entries={displayedEntries}
              onAddEntry={handleAddEntry}
              onEditEntry={handleEditEntry}
              onToggleStatus={handleToggleStatus}
              showBreaks={meta.showBreaks}
              filterSession={meta.viewMode as any}
              theme={currentTheme}
              searchQuery={searchQuery}
              isReadOnly={isReadOnly}
              onSyncCell={handleSyncCell}
              onSyncDay={handleSyncDay}
              onSyncPeriod={handleSyncPeriod}
            />
          )}
        </main>
      </div>

      {/* Footer */}
      <footer className="no-print mt-12 pt-6 border-t border-stone-200/60 text-center text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2 max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-1.5 font-medium">
          <span>Thời khóa biểu xinh xắn cho <strong>Lan Vy 🌸</strong> & <strong>Kim Ánh ✨</strong></span>
          <span className="text-pink-400">♥</span>
          <span>Dịu dàng, đồng bộ 2 chiều theo nhu cầu</span>
        </div>

        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={() => setIsSupabaseModalOpen(true)}
            className="hover:text-emerald-700 font-semibold transition-colors flex items-center gap-1"
          >
            <Database size={13} />
            <span>Tài liệu SQL Supabase & Vercel</span>
          </button>
          <span>•</span>
          <span className="text-slate-400">T2 - CN | Sáng 7h | Chiều 1h30 | Tối 17h-20h30</span>
        </div>
      </footer>

      {/* Edit Entry Modal */}
      <EditEntryModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSave={handleSaveEntry}
        onDelete={handleDeleteEntry}
        initialEntry={editingEntry}
        defaultDay={modalDefaultDay}
        defaultPeriodId={modalDefaultPeriodId}
        currentWorkspace={currentWorkspace}
      />

      {/* Supabase Guide & Direct Sync Modal */}
      <SupabaseGuideModal
        isOpen={isSupabaseModalOpen}
        onClose={() => setIsSupabaseModalOpen(false)}
        config={supabaseConfig}
        onSaveConfig={handleSaveSupabaseConfig}
        entries={entries}
        meta={meta}
        onSyncDataLoaded={handleSyncDataLoaded}
      />
    </div>
  );
}
