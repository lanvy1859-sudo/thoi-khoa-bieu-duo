import React from 'react';
import { TimetableEntry, PeriodDefinition, DayOfWeek, ThemeConfig } from '../types';
import { DAYS_OF_WEEK, PERIODS, COLOR_PALETTES } from '../constants/scheduleConfig';
import { Plus, Clock, MapPin, User, CheckCircle2, Circle, Edit3, Coffee, Sun, Sunset, Moon, Download } from 'lucide-react';

interface TimetableGridProps {
  entries: TimetableEntry[];
  onAddEntry: (day: DayOfWeek, periodId: string) => void;
  onEditEntry: (entry: TimetableEntry) => void;
  onToggleStatus: (entry: TimetableEntry) => void;
  showBreaks: boolean;
  filterSession: 'full' | 'morning' | 'afternoon' | 'evening';
  theme: ThemeConfig;
  searchQuery: string;
  isReadOnly?: boolean;
  onSyncCell?: (entry: TimetableEntry) => void;
  onSyncDay?: (day: DayOfWeek) => void;
  onSyncPeriod?: (periodId: string) => void;
}

export const TimetableGrid: React.FC<TimetableGridProps> = ({
  entries,
  onAddEntry,
  onEditEntry,
  onToggleStatus,
  showBreaks,
  filterSession,
  theme,
  searchQuery,
  isReadOnly = false,
  onSyncCell,
  onSyncDay,
  onSyncPeriod,
}) => {
  // Filter periods based on session
  const filteredPeriods = PERIODS.filter((p) => {
    if (filterSession === 'full') return true;
    return p.session === filterSession;
  });

  const getEntry = (day: DayOfWeek, periodId: string) => {
    return entries.find((e) => e.day === day && e.periodId === periodId);
  };

  const getPalette = (themeId: string) => {
    return COLOR_PALETTES.find((c) => c.id === themeId) || COLOR_PALETTES[0];
  };

  const matchesSearch = (entry?: TimetableEntry) => {
    if (!searchQuery.trim() || !entry) return true;
    const q = searchQuery.toLowerCase();
    return (
      entry.subject.toLowerCase().includes(q) ||
      (entry.teacher && entry.teacher.toLowerCase().includes(q)) ||
      (entry.room && entry.room.toLowerCase().includes(q)) ||
      (entry.notes && entry.notes.toLowerCase().includes(q))
    );
  };

  const getSessionIcon = (session: string) => {
    switch (session) {
      case 'morning':
        return <Sun size={13} className="text-amber-500" />;
      case 'afternoon':
        return <Sunset size={13} className="text-orange-500" />;
      case 'evening':
        return <Moon size={13} className="text-indigo-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="w-full overflow-x-auto pb-4">
      <div
        id="timetable-main-grid-card"
        className={`min-w-[980px] lg:min-w-full rounded-3xl ${theme.cardBg} border ${theme.borderColor} ${theme.glowEffect} overflow-hidden transition-all`}
      >
        {/* Table Header: Days of the Week */}
        <div className="grid grid-cols-[130px_repeat(7,1fr)] border-b border-stone-200/70 bg-stone-50/70">
          {/* Top-Left Corner: Time header */}
          <div className="p-3.5 flex flex-col justify-center items-center border-r border-stone-200/70 bg-stone-100/50">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Khung Giờ
            </span>
            <span className="text-xs font-semibold text-slate-600 flex items-center gap-1 mt-0.5">
              <Clock size={12} /> Tiết Học
            </span>
          </div>

          {/* Days */}
          {DAYS_OF_WEEK.map((day) => {
            const dayEntries = entries.filter((e) => e.day === day.id);
            return (
              <div
                key={day.id}
                id={`header-day-${day.id}`}
                className="p-3 text-center border-r border-stone-200/70 last:border-r-0 hover:bg-white/80 transition-colors flex flex-col items-center justify-between"
              >
                <div className="inline-flex items-center gap-1 text-sm font-bold text-slate-800 font-display">
                  <span>{day.icon}</span>
                  <span>{day.name}</span>
                </div>
                <div className="text-[11px] font-medium text-slate-500 mt-0.5 flex items-center justify-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-pink-400" />
                  <span>{dayEntries.length} tiết</span>
                </div>

                {/* Day Sync button if Read Only */}
                {isReadOnly && onSyncDay && dayEntries.length > 0 && (
                  <button
                    type="button"
                    onClick={() => onSyncDay(day.id)}
                    title={`Chép toàn bộ môn ${day.name} sang TKB của tôi`}
                    className="mt-1.5 inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-pink-50 hover:bg-pink-100 text-pink-600 font-bold border border-pink-200 shadow-2xs hover:scale-105 active:scale-95 transition-all"
                  >
                    <Download size={10} />
                    <span>Chép thứ</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* Periods Rows */}
        <div className="divide-y divide-stone-100/80">
          {filteredPeriods.map((period, pIdx) => {
            const isMorning = period.session === 'morning';
            const isAfternoon = period.session === 'afternoon';
            const isEvening = period.session === 'evening';
            const periodEntries = entries.filter((e) => e.periodId === period.id);

            return (
              <React.Fragment key={period.id}>
                <div
                  id={`period-row-${period.id}`}
                  className="grid grid-cols-[130px_repeat(7,1fr)] min-h-[96px] group/row"
                >
                  {/* Period Time Column */}
                  <div className="p-2.5 sm:p-3 border-r border-stone-200/70 bg-stone-50/40 flex flex-col justify-center items-center text-center">
                    <div className="flex items-center gap-1 text-xs font-bold text-slate-700">
                      {getSessionIcon(period.session)}
                      <span>{period.name}</span>
                    </div>
                    <div className="text-[11px] font-semibold text-slate-500 mt-0.5">
                      {period.startTime} - {period.endTime}
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-stone-200/60 text-slate-600 mt-1 font-medium">
                      {period.durationMinutes}p
                    </span>

                    {/* Period Sync button if Read Only */}
                    {isReadOnly && onSyncPeriod && periodEntries.length > 0 && (
                      <button
                        type="button"
                        onClick={() => onSyncPeriod(period.id)}
                        title={`Chép các môn ${period.name} sang TKB của tôi`}
                        className="mt-1 inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.5 rounded-md bg-pink-50 hover:bg-pink-100 text-pink-600 font-semibold border border-pink-200 shadow-2xs transition-all hover:scale-105"
                      >
                        <Download size={9} />
                        <span>Chép tiết</span>
                      </button>
                    )}
                  </div>

                  {/* 7 Days cells */}
                  {DAYS_OF_WEEK.map((day) => {
                    const entry = getEntry(day.id, period.id);
                    const palette = entry ? getPalette(entry.colorTheme) : null;
                    const isMatched = entry ? matchesSearch(entry) : true;

                    if (entry) {
                      return (
                        <div
                          key={day.id}
                          id={`cell-${day.id}-${period.id}`}
                          className={`p-1.5 border-r border-stone-100 last:border-r-0 relative transition-all ${
                            !isMatched ? 'opacity-30' : 'opacity-100'
                          }`}
                        >
                          <div
                            onClick={() => {
                              if (isReadOnly && onSyncCell) {
                                onSyncCell(entry);
                              } else if (!isReadOnly) {
                                onEditEntry(entry);
                              }
                            }}
                            className={`h-full min-h-[82px] p-2 rounded-2xl border ${palette?.bg} ${palette?.border} hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group relative overflow-hidden`}
                          >
                            {/* Top row: sticker & actions */}
                            <div className="flex items-start justify-between gap-1">
                              <span className="text-base p-0.5 rounded-md">
                                {entry.icon || '🌸'}
                              </span>

                              {isReadOnly ? (
                                onSyncCell && (
                                  <button
                                    type="button"
                                    title="Chép môn này sang TKB của tôi"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onSyncCell(entry);
                                    }}
                                    className="px-2 py-0.5 rounded-lg bg-pink-500 hover:bg-pink-600 text-white text-[10px] font-bold flex items-center gap-1 shadow-xs hover:scale-105 active:scale-95 transition-all"
                                  >
                                    <Download size={10} />
                                    <span>Chép</span>
                                  </button>
                                )
                              ) : (
                                <div className="flex items-center gap-1">
                                  <button
                                    type="button"
                                    title="Đổi trạng thái học"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onToggleStatus(entry);
                                    }}
                                    className="text-slate-400 hover:text-pink-600 transition-colors p-0.5 rounded-md hover:bg-white/60"
                                  >
                                    {entry.status === 'done' ? (
                                      <CheckCircle2 size={14} className="text-emerald-500" />
                                    ) : (
                                      <Circle size={14} className="text-stone-400" />
                                    )}
                                  </button>
                                  <span className="opacity-0 group-hover:opacity-100 text-[10px] text-slate-400 hover:text-slate-600 transition-opacity">
                                    <Edit3 size={12} />
                                  </span>
                                </div>
                              )}
                            </div>

                            {/* Middle: Subject Name */}
                            <div className="my-1">
                              <div
                                className={`text-xs font-bold leading-tight line-clamp-2 ${palette?.text} font-display ${
                                  entry.status === 'done' ? 'line-through opacity-70' : ''
                                }`}
                              >
                                {entry.subject}
                              </div>
                            </div>

                            {/* Bottom: Location, Teacher, or Notes */}
                            <div className="space-y-0.5 text-[10px] text-slate-500 font-medium">
                              {entry.room && (
                                <div className="flex items-center gap-1 truncate text-slate-600">
                                  <MapPin size={10} className="flex-shrink-0 text-slate-400" />
                                  <span className="truncate">{entry.room}</span>
                                </div>
                              )}
                              {entry.teacher && !entry.room && (
                                <div className="flex items-center gap-1 truncate text-slate-600">
                                  <User size={10} className="flex-shrink-0 text-slate-400" />
                                  <span className="truncate">{entry.teacher}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    }

                    // Empty cell
                    if (isReadOnly) {
                      return (
                        <div
                          key={day.id}
                          id={`empty-cell-${day.id}-${period.id}`}
                          className="p-1.5 border-r border-stone-100 last:border-r-0 flex items-center justify-center"
                        >
                          <div className="w-full h-full min-h-[82px] rounded-2xl border border-dashed border-stone-100 bg-stone-50/20 flex flex-col items-center justify-center text-stone-300">
                            <span className="text-xs opacity-40">·</span>
                          </div>
                        </div>
                      );
                    }

                    return (
                      <div
                        key={day.id}
                        id={`empty-cell-${day.id}-${period.id}`}
                        onClick={() => onAddEntry(day.id, period.id)}
                        className="p-1.5 border-r border-stone-100 last:border-r-0 hover:bg-pink-50/30 transition-colors cursor-pointer group flex items-center justify-center"
                      >
                        <div className="w-full h-full min-h-[82px] rounded-2xl border border-dashed border-stone-200/80 group-hover:border-pink-300 group-hover:bg-white/80 transition-all flex flex-col items-center justify-center gap-1 text-slate-300 group-hover:text-pink-500">
                          <Plus
                            size={16}
                            className="transition-transform group-hover:scale-125"
                          />
                          <span className="text-[10px] font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
                            Thêm tiết
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Optional Break Bar row */}
                {showBreaks && period.breakAfterMinutes && period.breakAfterMinutes > 0 && (
                  <div
                    id={`break-row-${period.id}`}
                    className={`grid grid-cols-[130px_1fr] border-y border-stone-100/90 py-1.5 px-3 transition-colors ${
                      period.breakAfterMinutes >= 15
                        ? 'bg-gradient-to-r from-amber-50/90 via-orange-50/50 to-amber-50/90 text-amber-800'
                        : 'bg-stone-50/70 text-slate-500'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-[11px] font-bold">
                      <Coffee size={13} className="text-amber-600 flex-shrink-0" />
                      <span>{period.breakAfterMinutes >= 60 ? 'Nghỉ trưa' : `Ra chơi ${period.breakAfterMinutes}p`}</span>
                    </div>
                    <div className="text-[11px] font-medium flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                      <span>{period.breakLabel}</span>
                    </div>
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>
    </div>
  );
};
