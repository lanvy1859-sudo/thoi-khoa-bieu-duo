import React, { useState } from 'react';
import { SupabaseConfig, TimetableEntry, TimetableMeta } from '../types';
import { DEFAULT_SQL_SCHEMA, testSupabaseConnection, syncToSupabase, syncFromSupabase } from '../lib/supabaseClient';
import { Database, Copy, Check, ExternalLink, RefreshCw, Sparkles, ShieldCheck, AlertCircle, HelpCircle, Layers, Terminal, Globe, GitBranch } from 'lucide-react';
import confetti from 'canvas-confetti';

interface SupabaseGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SupabaseConfig;
  onSaveConfig: (config: SupabaseConfig) => void;
  entries: TimetableEntry[];
  meta: TimetableMeta;
  onSyncDataLoaded: (entries: TimetableEntry[], meta?: TimetableMeta) => void;
}

export const SupabaseGuideModal: React.FC<SupabaseGuideModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  entries,
  meta,
  onSyncDataLoaded,
}) => {
  const [activeTab, setActiveTab] = useState<'steps' | 'sql' | 'connect' | 'vercel' | 'faq'>('vercel');
  const [copiedSql, setCopiedSql] = useState(false);
  const [copiedGit, setCopiedGit] = useState(false);
  const [url, setUrl] = useState(config.url || '');
  const [anonKey, setAnonKey] = useState(config.anonKey || '');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopySql = () => {
    navigator.clipboard.writeText(DEFAULT_SQL_SCHEMA);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    const newConfig: SupabaseConfig = {
      ...config,
      url: url.trim(),
      anonKey: anonKey.trim(),
    };
    const result = await testSupabaseConnection(newConfig);
    setIsTesting(false);
    setTestResult(result);
    if (result.success) {
      onSaveConfig({
        ...newConfig,
        connected: true,
        lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
      });
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
      });
    }
  };

  const handlePushToSupabase = async () => {
    if (!url || !anonKey) {
      setTestResult({ success: false, message: 'Vui lòng nhập Supabase Project URL và Anon Key trước.' });
      return;
    }
    setIsSyncing(true);
    setSyncStatusMsg('Đang tải dữ liệu thời khóa biểu lên Supabase...');
    try {
      const activeConfig: SupabaseConfig = {
        ...config,
        url: url.trim(),
        anonKey: anonKey.trim(),
      };
      await syncToSupabase(activeConfig, entries, meta);
      setSyncStatusMsg('Đồng bộ thành công! Toàn bộ các tiết học đã được lưu an toàn vào Supabase database.');
      onSaveConfig({
        ...activeConfig,
        connected: true,
        lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
      });
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch (err: any) {
      setSyncStatusMsg(`Lỗi khi đẩy dữ liệu: ${err.message || String(err)}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const handlePullFromSupabase = async () => {
    if (!url || !anonKey) {
      setTestResult({ success: false, message: 'Vui lòng nhập Supabase Project URL và Anon Key trước.' });
      return;
    }
    setIsSyncing(true);
    setSyncStatusMsg('Đang lấy dữ liệu thời khóa biểu từ Supabase về...');
    try {
      const activeConfig: SupabaseConfig = {
        ...config,
        url: url.trim(),
        anonKey: anonKey.trim(),
      };
      const result = await syncFromSupabase(activeConfig);
      if (result) {
        onSyncDataLoaded(result.entries, result.meta);
        setSyncStatusMsg(`Đã tải về thành công ${result.entries.length} tiết học từ Supabase!`);
        onSaveConfig({
          ...activeConfig,
          connected: true,
          lastSyncedAt: new Date().toLocaleTimeString('vi-VN'),
        });
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.6 },
        });
      }
    } catch (err: any) {
      setSyncStatusMsg(`Lỗi khi tải dữ liệu: ${err.message || String(err)}`);
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div
      id="supabase-guide-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/40 backdrop-blur-xs transition-opacity overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="supabase-guide-modal-content"
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-stone-200/90 p-5 sm:p-7 my-6 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top */}
        <div className="flex items-center justify-between pb-4 border-b border-stone-100 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-50 border border-emerald-200/80 flex items-center justify-center text-emerald-600">
              <Database size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-800 font-display">
                  Cơ Sở Dữ Liệu Supabase
                </h3>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold">
                  PostgreSQL Cloud
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Hướng dẫn thiết lập bảng & kết nối lưu trữ vĩnh viễn thời khóa biểu
              </p>
            </div>
          </div>
          <button
            id="close-supabase-modal-btn"
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-2 rounded-full hover:bg-stone-100 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex gap-1.5 p-1 bg-stone-100/90 rounded-2xl my-4 text-xs font-semibold flex-shrink-0 flex-wrap sm:flex-nowrap">
          <button
            type="button"
            id="tab-guide-vercel"
            onClick={() => setActiveTab('vercel')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'vercel'
                ? 'bg-white text-emerald-800 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>🚀</span>
            <span>Đẩy Lên Vercel</span>
          </button>
          <button
            type="button"
            id="tab-guide-connect"
            onClick={() => setActiveTab('connect')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'connect'
                ? 'bg-white text-emerald-800 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>🔗</span>
            <span>Kết Nối Trực Tiếp</span>
          </button>
          <button
            type="button"
            id="tab-guide-sql"
            onClick={() => setActiveTab('sql')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'sql'
                ? 'bg-white text-emerald-800 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>⚡</span>
            <span>Mã SQL Tạo Bảng</span>
          </button>
          <button
            type="button"
            id="tab-guide-steps"
            onClick={() => setActiveTab('steps')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'steps'
                ? 'bg-white text-emerald-800 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>📖</span>
            <span>4 Bước Supabase</span>
          </button>
          <button
            type="button"
            id="tab-guide-faq"
            onClick={() => setActiveTab('faq')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'faq'
                ? 'bg-white text-emerald-800 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>💡</span>
            <span>FAQ</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="overflow-y-auto flex-1 pr-1 space-y-4 text-slate-700 text-sm">
          {activeTab === 'vercel' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-50 to-pink-50 border border-emerald-200/90 text-xs text-slate-700 flex items-start gap-3">
                <Globe className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="text-emerald-900 text-sm block">Đồng bộ dữ liệu 100% khi triển khai Vercel</strong>
                  <p className="mt-1 text-slate-600 leading-relaxed">
                    Dự án đã được tích hợp sẵn <code>vercel.json</code>, cấu hình <code>vite.config.ts</code> chuẩn SPA, và cơ chế tự động nhận diện biến môi trường <code>VITE_SUPABASE_URL</code> + <code>VITE_SUPABASE_ANON_KEY</code>. Khi deploy lên Vercel, bạn mở link trên điện thoại hay bất kỳ máy tính nào thì dữ liệu đều tự động đồng bộ thời gian thực!
                  </p>
                </div>
              </div>

              {/* Step 1: Git & GitHub */}
              <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50/70 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-pink-100 text-pink-700 font-bold flex items-center justify-center text-xs">
                      1
                    </span>
                    <h4 className="font-bold text-slate-800 text-sm">Đẩy mã nguồn lên GitHub</h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const gitCommands = `git init\ngit add .\ngit commit -m "feat: thoi khoa bieu xinh canva"\ngit branch -M main\ngit remote add origin https://github.com/<your-username>/<repo-name>.git\ngit push -u origin main`;
                      navigator.clipboard.writeText(gitCommands);
                      setCopiedGit(true);
                      setTimeout(() => setCopiedGit(false), 2000);
                    }}
                    className="px-2.5 py-1 bg-white hover:bg-stone-100 border border-stone-200 rounded-lg text-xs font-semibold text-slate-700 flex items-center gap-1 transition-colors"
                  >
                    {copiedGit ? <Check size={12} className="text-emerald-600" /> : <Copy size={12} />}
                    <span>{copiedGit ? 'Đã sao chép!' : 'Copy lệnh Git'}</span>
                  </button>
                </div>
                <p className="text-xs text-slate-600">
                  Mở Terminal tại thư mục dự án và chạy các lệnh sau (nhớ thay URL GitHub repository của bạn):
                </p>
                <div className="p-3 bg-slate-900 rounded-xl font-mono text-xs text-emerald-300 overflow-x-auto space-y-1">
                  <div><span className="text-slate-500"># Khởi tạo và commit</span></div>
                  <div>git init</div>
                  <div>git add .</div>
                  <div>git commit -m "feat: thoi khoa bieu xinh canva"</div>
                  <div>git branch -M main</div>
                  <div><span className="text-slate-500"># Thay bằng link repo GitHub của bạn</span></div>
                  <div>git remote add origin https://github.com/&lt;user&gt;/&lt;repo&gt;.git</div>
                  <div>git push -u origin main</div>
                </div>
              </div>

              {/* Step 2: Import on Vercel */}
              <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50/70 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center text-xs">
                    2
                  </span>
                  <h4 className="font-bold text-slate-800 text-sm">Kết nối GitHub trên Vercel</h4>
                </div>
                <p className="text-xs text-slate-600">
                  Truy cập{' '}
                  <a
                    href="https://vercel.com"
                    target="_blank"
                    rel="noreferrer"
                    className="text-emerald-600 font-semibold underline inline-flex items-center gap-0.5"
                  >
                    vercel.com <ExternalLink size={12} />
                  </a>
                  {' '}&gt; đăng nhập bằng GitHub &gt; bấm <strong>Add New...</strong> &gt; chọn <strong>Project</strong> &gt; chọn Repository bạn vừa push. Vercel sẽ tự nhận diện Framework là <strong>Vite</strong>.
                </p>
              </div>

              {/* Step 3: Add Environment Variables */}
              <div className="p-4 rounded-2xl border border-amber-200 bg-amber-50/50 space-y-2.5">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-amber-100 text-amber-700 font-bold flex items-center justify-center text-xs">
                    3
                  </span>
                  <h4 className="font-bold text-slate-800 text-sm">Cài đặt 2 Biến Môi Trường trên Vercel (Quan trọng)</h4>
                </div>
                <p className="text-xs text-slate-600">
                  Trong giao diện thiết lập trước khi Deploy (hoặc vào <em>Project Settings &gt; Environment Variables</em>), thêm 2 biến sau:
                </p>
                <div className="grid grid-cols-1 gap-2 font-mono text-xs">
                  <div className="p-2.5 bg-white rounded-xl border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <span className="font-bold text-slate-800">VITE_SUPABASE_URL</span>
                    <span className="text-slate-500 text-[11px] font-sans">URL dự án Supabase (vd: <code>https://xyz.supabase.co</code>)</span>
                  </div>
                  <div className="p-2.5 bg-white rounded-xl border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <span className="font-bold text-slate-800">VITE_SUPABASE_ANON_KEY</span>
                    <span className="text-slate-500 text-[11px] font-sans">Chuỗi Anon Public Key từ Supabase Settings &gt; API</span>
                  </div>
                </div>
                <div className="text-[11px] text-amber-800 bg-amber-100/70 p-2 rounded-lg">
                  💡 <em>Mẹo:</em> Khi bạn đã đặt 2 biến này trên Vercel, bất kỳ ai mở link Vercel của bạn cũng xem được thời khóa biểu đồng bộ mà không cần phải nhập mã khóa nữa!
                </div>
              </div>

              {/* Step 4: Click Deploy & Enjoy */}
              <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50/70 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-purple-100 text-purple-700 font-bold flex items-center justify-center text-xs">
                    4
                  </span>
                  <h4 className="font-bold text-slate-800 text-sm">Bấm "Deploy" & Lấy link dùng ngay!</h4>
                </div>
                <p className="text-xs text-slate-600">
                  Vercel sẽ build trong khoảng 20-30 giây và cấp cho bạn đường link (ví dụ: <code>https://thoi-khoa-bieu-xinh.vercel.app</code>).
                </p>
                <ul className="list-disc list-inside text-xs text-slate-600 space-y-1 mt-1">
                  <li><strong>Tự động tải về:</strong> Mở link trên điện thoại hoặc máy khác, thời khóa biểu tự tải ngay từ Supabase Cloud.</li>
                  <li><strong>Realtime 2 chiều:</strong> Chỉnh sửa trên laptop thì điện thoại cập nhật ngay lập tức.</li>
                  <li><strong>Offline an toàn:</strong> Nếu mất mạng, app vẫn lưu vào bộ nhớ máy và tự đồng bộ khi có kết nối trở lại.</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'steps' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-3.5 rounded-2xl bg-emerald-50/80 border border-emerald-200/80 text-xs text-emerald-900 flex items-start gap-2.5">
                <Sparkles className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                <div>
                  <strong>Tại sao nên dùng Supabase cho Thời Khóa Biểu?</strong>
                  <p className="mt-0.5 text-emerald-800">
                    Supabase là nền tảng Backend-as-a-Service mã nguồn mở mạnh mẽ nhất dựa trên PostgreSQL.
                    Miễn phí trọn đời cho dự án cá nhân, có giao diện bảng như Airtable/Canva và đồng bộ dữ liệu theo thời gian thực (Realtime)!
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {/* Step 1 */}
                <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50/60 flex items-start gap-3">
                  <div className="w-7 h-7 rounded-xl bg-pink-100 text-pink-700 font-bold flex items-center justify-center flex-shrink-0 text-sm">
                    1
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 text-sm">Tạo Project Supabase miễn phí</h4>
                    <p className="text-xs text-slate-600 mt-1">
                      Truy cập{' '}
                      <a
                        href="https://supabase.com"
                        target="_blank"
                        rel="noreferrer"
                        className="text-emerald-600 font-semibold underline inline-flex items-center gap-0.5"
                      >
                        supabase.com <ExternalLink size={12} />
                      </a>
                      , đăng nhập bằng GitHub hoặc Email, sau đó nhấn <strong>New Project</strong> (đặt tên ví dụ: <code>ThoiKhoaBieuXinh</code> và chọn Password).
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50/60 flex items-start gap-3">
                  <div className="w-7 h-7 rounded-xl bg-amber-100 text-amber-700 font-bold flex items-center justify-center flex-shrink-0 text-sm">
                    2
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 text-sm">Chạy mã SQL tạo bảng (1 Cú Click)</h4>
                    <p className="text-xs text-slate-600 mt-1">
                      Tại thanh bên trái của Supabase Dashboard, chọn biểu tượng <strong>SQL Editor</strong> &gt; nhấn <strong>New query</strong>.
                      Chuyển sang tab <strong>"Mã SQL Tạo Bảng"</strong> bên cạnh, copy toàn bộ script và dán vào, sau đó nhấn <strong>Run</strong> (hoặc Ctrl+Enter).
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50/60 flex items-start gap-3">
                  <div className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center flex-shrink-0 text-sm">
                    3
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 text-sm">Lấy Project URL & Anon Public Key</h4>
                    <p className="text-xs text-slate-600 mt-1">
                      Vào <strong>Project Settings</strong> (biểu tượng bánh răng ⚙️ ở góc dưới cùng bên trái) &gt; chọn mục <strong>API</strong>.
                      Copy 2 dòng:
                    </p>
                    <ul className="list-disc list-inside text-xs text-slate-600 mt-1 space-y-0.5">
                      <li><strong>Project URL</strong> (dạng <code>https://xyzcompany.supabase.co</code>)</li>
                      <li><strong>anon public key</strong> (chuỗi mã dài an toàn dùng cho trình duyệt)</li>
                    </ul>
                  </div>
                </div>

                {/* Step 4 */}
                <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50/60 flex items-start gap-3">
                  <div className="w-7 h-7 rounded-xl bg-purple-100 text-purple-700 font-bold flex items-center justify-center flex-shrink-0 text-sm">
                    4
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 text-sm">Dán vào App & Bấm "Đồng Bộ"</h4>
                    <p className="text-xs text-slate-600 mt-1">
                      Mở tab <strong>"Kết Nối Trực Tiếp"</strong> ở đây, dán URL và Anon Key vào. Nhấn <strong>Kiểm Tra Kết Nối</strong> rồi nhấn <strong>Đẩy thời khóa biểu lên Supabase</strong> là xong! Dữ liệu của bạn sẽ được lưu trên mây vĩnh viễn.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'sql' && (
            <div className="space-y-3 animate-fadeIn">
              <div className="flex items-center justify-between">
                <div className="text-xs text-slate-500">
                  Đoạn mã SQL đầy đủ đã được tối ưu bảo mật RLS và định dạng đúng các tiết học.
                </div>
                <button
                  type="button"
                  id="copy-sql-btn"
                  onClick={handleCopySql}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                    copiedSql
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-stone-100 hover:bg-stone-200 text-slate-700'
                  }`}
                >
                  {copiedSql ? <Check size={14} /> : <Copy size={14} />}
                  <span>{copiedSql ? 'Đã sao chép!' : 'Sao chép mã SQL'}</span>
                </button>
              </div>

              <div className="relative rounded-2xl bg-slate-900 p-4 font-mono text-xs text-emerald-300 overflow-x-auto max-h-72 border border-slate-800">
                <pre>{DEFAULT_SQL_SCHEMA}</pre>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="font-bold text-slate-800 block mb-1">📋 Bảng timetable_entries</span>
                  <span className="text-slate-600">
                    Lưu danh sách các tiết học: thứ trong tuần (<code>day</code>), tiết (<code>period_id</code>), tên môn (<code>subject</code>), phòng học, giảng viên, màu sắc thẻ, sticker icon.
                  </span>
                </div>
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="font-bold text-slate-800 block mb-1">⚙️ Bảng timetable_meta</span>
                  <span className="text-slate-600">
                    Lưu tiêu đề thời khóa biểu, câu quote truyền cảm hứng, tên người sở hữu, học kỳ và theme phong cách Canva đang chọn.
                  </span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'connect' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <ShieldCheck size={16} className="text-emerald-600" />
                  Cấu hình Supabase Credentials
                </h4>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Supabase Project URL
                  </label>
                  <input
                    id="input-supabase-url"
                    type="text"
                    placeholder="https://your-project-id.supabase.co"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    className="w-full px-3.5 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono text-slate-800 focus:ring-2 focus:ring-emerald-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Supabase Anon Public Key (Khóa công khai)
                  </label>
                  <input
                    id="input-supabase-anon-key"
                    type="password"
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                    value={anonKey}
                    onChange={(e) => setAnonKey(e.target.value)}
                    className="w-full px-3.5 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono text-slate-800 focus:ring-2 focus:ring-emerald-400 focus:outline-none"
                  />
                  <span className="text-[11px] text-slate-400 mt-0.5 block">
                    Khóa Anon là an toàn trên trình duyệt, không bao giờ dùng Service Role Key bí mật tại đây.
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    type="button"
                    id="btn-test-connection"
                    disabled={isTesting}
                    onClick={handleTestConnection}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all disabled:opacity-50"
                  >
                    {isTesting ? <RefreshCw size={14} className="animate-spin" /> : <ShieldCheck size={14} />}
                    <span>Kiểm Tra Kết Nối</span>
                  </button>

                  {config.connected && (
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-semibold flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      Đã kết nối {config.lastSyncedAt ? `(${config.lastSyncedAt})` : ''}
                    </span>
                  )}
                </div>

                {testResult && (
                  <div
                    className={`p-3 rounded-xl text-xs flex items-start gap-2 ${
                      testResult.success
                        ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                        : 'bg-rose-50 border border-rose-200 text-rose-800'
                    }`}
                  >
                    {testResult.success ? <Check size={16} className="text-emerald-600 flex-shrink-0" /> : <AlertCircle size={16} className="text-rose-600 flex-shrink-0" />}
                    <span>{testResult.message}</span>
                  </div>
                )}
              </div>

              {/* Sync Actions */}
              <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-3">
                <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <RefreshCw size={15} className="text-pink-500" />
                  Đồng bộ hai chiều dữ liệu (Cloud Sync)
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    id="btn-push-to-supabase"
                    disabled={isSyncing}
                    onClick={handlePushToSupabase}
                    className="p-3 bg-pink-50 hover:bg-pink-100 border border-pink-200/80 rounded-xl text-left transition-all group"
                  >
                    <div className="text-xs font-bold text-pink-700 flex items-center justify-between">
                      <span>⬆️ Đẩy lên Supabase</span>
                      <span className="text-[10px] bg-pink-200/60 px-1.5 py-0.5 rounded text-pink-800">
                        {entries.length} tiết
                      </span>
                    </div>
                    <p className="text-[11px] text-pink-600/80 mt-1">
                      Lưu thời khóa biểu hiện tại từ máy lên cơ sở dữ liệu Supabase.
                    </p>
                  </button>

                  <button
                    type="button"
                    id="btn-pull-from-supabase"
                    disabled={isSyncing}
                    onClick={handlePullFromSupabase}
                    className="p-3 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 rounded-xl text-left transition-all group"
                  >
                    <div className="text-xs font-bold text-emerald-700 flex items-center justify-between">
                      <span>⬇️ Tải từ Supabase về</span>
                    </div>
                    <p className="text-[11px] text-emerald-600/80 mt-1">
                      Lấy dữ liệu đã lưu từ Cloud về hiển thị lên giao diện thời khóa biểu.
                    </p>
                  </button>
                </div>

                {syncStatusMsg && (
                  <div className="p-2.5 rounded-xl bg-stone-100 text-xs font-medium text-slate-700">
                    {syncStatusMsg}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'faq' && (
            <div className="space-y-3 animate-fadeIn text-xs text-slate-600">
              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200">
                <h4 className="font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                  <HelpCircle size={15} className="text-pink-500" />
                  Nếu tôi chưa cấu hình Supabase thì app có lưu được không?
                </h4>
                <p>
                  <strong>Có!</strong> Ứng dụng đã tự động lưu dữ liệu vào <code>localStorage</code> của trình duyệt ngay khi bạn thay đổi bất kỳ ô tiết học nào. Khi nào bạn muốn đồng bộ sang máy khác hoặc lưu trữ đám mây lâu dài, bạn chỉ cần tạo bảng Supabase theo hướng dẫn ở Tab 1 & Tab 2.
                </p>
              </div>

              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200">
                <h4 className="font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                  <Layers size={15} className="text-emerald-500" />
                  Làm sao để xem bảng trực tiếp dạng spreadsheet trên Supabase?
                </h4>
                <p>
                  Vào Supabase Dashboard &gt; chọn biểu tượng <strong>Table Editor</strong> ở menu bên trái &gt; chọn bảng <code>timetable_entries</code>. Bạn sẽ thấy từng dòng dữ liệu hiển thị trực quan như một trang tính Excel/Notion cực kỳ đẹp và có thể chỉnh sửa trực tiếp.
                </p>
              </div>

              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200">
                <h4 className="font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                  <Sparkles size={15} className="text-amber-500" />
                  Supabase có tốn phí không?
                </h4>
                <p>
                  Gói Free Tier của Supabase cung cấp miễn phí tới 500MB cơ sở dữ liệu PostgreSQL và 50.000 người dùng hàng tháng. Đối với nhu cầu lưu thời khóa biểu cá nhân hoặc nhóm bạn, nó hoàn toàn <strong>miễn phí trọn đời (100% Free)</strong>.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-stone-100 flex items-center justify-between flex-shrink-0 mt-3">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Tự động lưu Offline & Hỗ trợ Supabase Cloud</span>
          </div>
          <button
            type="button"
            id="close-guide-done-btn"
            onClick={onClose}
            className="px-5 py-2 bg-stone-800 hover:bg-black text-white text-xs font-bold rounded-xl transition-all"
          >
            Đóng Hướng Dẫn
          </button>
        </div>
      </div>
    </div>
  );
};
