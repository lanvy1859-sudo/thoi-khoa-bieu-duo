import React from 'react';
import { TimetableEntry, DayOfWeek, ThemeConfig } from '../types';
import { DAYS_OF_WEEK, PERIODS, COLOR_PALETTES } from '../constants/scheduleConfig';
import { Clock, MapPin, User, FileText, CheckCircle2, Circle, Plus, Coffee, Calendar, Download } from 'lucide-react';

interface DailyViewProps {
  entries: TimetableEntry[];
  selectedDay: DayOfWeek;
  onSelectDay: (day: DayOfWeek) => void;
  onAddEntry: (day: DayOfWeek, periodId: string) => void;
  onEditEntry: (entry: TimetableEntry) => void;
  onToggleStatus: (entry: TimetableEntry) => void;
  theme: ThemeConfig;
  isReadOnly?: boolean;
  onSyncCell?: (entry: TimetableEntry) => void;
  onSyncDay?: (day: DayOfWeek) => void;
}

export const DailyView: React.FC<DailyViewProps> = ({
  entries,
  selectedDay,
  onSelectDay,
  onAddEntry,
  onEditEntry,
  onToggleStatus,
  theme,
  isReadOnly = false,
  onSyncCell,
  onSyncDay,
}) => {
  const currentDayInfo = DAYS_OF_WEEK.find((d) => d.id === selectedDay) || DAYS_OF_WEEK[0];
  const dayEntries = entries.filter((e) => e.day === selectedDay);

  const getEntryForPeriod = (periodId: string) => {
    return dayEntries.find((e) => e.periodId === periodId);
  };

  const getPalette = (themeId: string) => {
    return COLOR_PALETTES.find((c) => c.id === themeId) || COLOR_PALETTES[0];
  };

  return (
    <div id="daily-view-container" className="space-y-6 max-w-3xl mx-auto">
      {/* Day Selector Pills */}
      <div className="flex items-center justify-between gap-1.5 p-1.5 bg-white/80 backdrop-blur-xs border border-stone-200 rounded-2xl overflow-x-auto">
        {DAYS_OF_WEEK.map((day) => {
          const isSelected = day.id === selectedDay;
          const count = entries.filter((e) => e.day === day.id).length;
          return (
            <button
              key={day.id}
              type="button"
              id={`daily-day-pill-${day.id}`}
              onClick={() => onSelectDay(day.id)}
              className={`flex-1 min-w-[72px] py-2 px-3 rounded-xl transition-all text-center flex flex-col items-center gap-0.5 ${
                isSelected
                  ? 'bg-gradient-to-br from-pink-400 to-rose-400 text-white shadow-md shadow-pink-200/50 font-bold scale-102'
                  : 'text-slate-600 hover:bg-stone-100 font-medium'
              }`}
            >
              <span className="text-base">{day.icon}</span>
              <span className="text-xs">{day.name}</span>
              <span className={`text-[10px] ${isSelected ? 'text-pink-100' : 'text-slate-400'}`}>
                {count} tiết
              </span>
            </button>
          );
        })}
      </div>

      {/* Selected Day Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-pink-50/70 via-rose-50/50 to-amber-50/70 border border-pink-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="text-3xl p-2.5 bg-white rounded-2xl shadow-xs border border-pink-100">
            {currentDayInfo.icon}
          </span>
          <div>
            <h3 className="text-xl font-bold text-slate-800 font-display">
              Lịch Học {currentDayInfo.name}
            </h3>
            <p className="text-xs text-slate-500">
              Tổng cộng {dayEntries.length} tiết học được lên lịch cho ngày này
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isReadOnly && onSyncDay && dayEntries.length > 0 && (
            <button
              type="button"
              onClick={() => onSyncDay(selectedDay)}
              className="px-3.5 py-2 rounded-xl bg-pink-500 hover:bg-pink-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all hover:scale-105 active:scale-95"
            >
              <Download size={14} />
              <span>Chép cả {currentDayInfo.name} sang TKB của tôi</span>
            </button>
          )}

          <div className="text-xs font-bold text-pink-600 bg-white px-3 py-1.5 rounded-xl border border-pink-100 shadow-xs flex items-center gap-1.5">
            <Calendar size={14} />
            <span>Chế độ Daily Focus</span>
          </div>
        </div>
      </div>

      {/* Timeline List */}
      <div className="space-y-3">
        {PERIODS.map((period) => {
          const entry = getEntryForPeriod(period.id);
          const palette = entry ? getPalette(entry.colorTheme) : null;

          return (
            <div key={period.id} className="space-y-2">
              {/* Entry Card */}
              {entry ? (
                <div
                  id={`daily-card-${entry.id}`}
                  onClick={() => {
                    if (isReadOnly && onSyncCell) {
                      onSyncCell(entry);
                    } else if (!isReadOnly) {
                      onEditEntry(entry);
                    }
                  }}
                  className={`p-4 rounded-2xl border ${palette?.bg} ${palette?.border} hover:shadow-md transition-all cursor-pointer relative group flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3`}
                >
                  <div className="flex items-start sm:items-center gap-3.5 flex-1">
                    <span className="text-2xl p-2 bg-white/80 rounded-2xl border border-white/60 shadow-xs flex-shrink-0">
                      {entry.icon || '🌸'}
                    </span>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-lg bg-white/70 text-slate-600 border border-stone-200/60 flex items-center gap-1">
                          <Clock size={11} /> {period.startTime} - {period.endTime} ({period.name})
                        </span>
                        {entry.room && (
                          <span className="text-[11px] font-medium px-2 py-0.5 rounded-lg bg-white/70 text-slate-600 border border-stone-200/60 flex items-center gap-1">
                            <MapPin size={11} /> {entry.room}
                          </span>
                        )}
                        {entry.teacher && (
                          <span className="text-[11px] font-medium px-2 py-0.5 rounded-lg bg-white/70 text-slate-600 border border-stone-200/60 flex items-center gap-1">
                            <User size={11} /> {entry.teacher}
                          </span>
                        )}
                      </div>

                      <h4
                        className={`text-base font-bold ${palette?.text} font-display ${
                          entry.status === 'done' ? 'line-through opacity-70' : ''
                        }`}
                      >
                        {entry.subject}
                      </h4>

                      {entry.notes && (
                        <p className="text-xs text-slate-600 flex items-center gap-1 mt-0.5">
                          <FileText size={12} className="text-slate-400" />
                          <span>{entry.notes}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 self-end sm:self-center">
                    {isReadOnly ? (
                      onSyncCell && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onSyncCell(entry);
                          }}
                          className="px-3.5 py-1.5 rounded-xl bg-pink-500 hover:bg-pink-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all hover:scale-105 active:scale-95"
                        >
                          <Download size={13} />
                          <span>Chép sang TKB của tôi</span>
                        </button>
                      )
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleStatus(entry);
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                          entry.status === 'done'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-white/80 hover:bg-white text-slate-700 border border-stone-200'
                        }`}
                      >
                        {entry.status === 'done' ? (
                          <>
                            <CheckCircle2 size={15} className="text-emerald-600" />
                            <span>Đã xong</span>
                          </>
                        ) : (
                          <>
                            <Circle size={15} className="text-stone-400" />
                            <span>Chưa học</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                /* Empty Period row */
                isReadOnly ? (
                  <div
                    id={`daily-empty-${period.id}`}
                    className="p-3 rounded-2xl border border-stone-100 bg-stone-50/20 flex items-center justify-between text-slate-400"
                  >
                    <div className="flex items-center gap-2.5 text-xs font-medium">
                      <span className="px-2 py-0.5 rounded-md bg-stone-100 text-slate-500 font-mono text-[11px]">
                        {period.startTime} - {period.endTime}
                      </span>
                      <span>{period.name}</span>
                      <span className="text-stone-300">·</span>
                      <span className="text-stone-400 text-xs italic">
                        Không có tiết học
                      </span>
                    </div>
                  </div>
                ) : (
                  <div
                    id={`daily-empty-${period.id}`}
                    onClick={() => onAddEntry(selectedDay, period.id)}
                    className="p-3 rounded-2xl border border-dashed border-stone-200 hover:border-pink-300 hover:bg-pink-50/20 transition-all cursor-pointer flex items-center justify-between text-slate-400 hover:text-pink-600 group"
                  >
                    <div className="flex items-center gap-2.5 text-xs font-medium">
                      <span className="px-2 py-0.5 rounded-md bg-stone-100 text-slate-500 font-mono text-[11px]">
                        {period.startTime} - {period.endTime}
                      </span>
                      <span>{period.name}</span>
                      <span className="text-slate-300">|</span>
                      <span className="text-slate-400 group-hover:text-pink-600 text-xs">
                        Chưa có lịch học
                      </span>
                    </div>

                    <div className="text-xs font-semibold flex items-center gap-1 text-slate-400 group-hover:text-pink-500">
                      <Plus size={14} />
                      <span>Thêm tiết</span>
                    </div>
                  </div>
                )
              )}

              {/* Break Info after period */}
              {period.breakAfterMinutes && period.breakAfterMinutes > 0 && (
                <div className="px-4 py-1.5 rounded-xl bg-amber-50/60 border border-amber-100/70 text-[11px] text-amber-800 flex items-center gap-2">
                  <Coffee size={13} className="text-amber-600" />
                  <span className="font-semibold">{period.breakLabel}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
