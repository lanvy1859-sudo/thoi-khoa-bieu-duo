import React from 'react';
import { CUTE_STICKERS } from '../constants/scheduleConfig';

interface AestheticStickerSelectorProps {
  selectedIcon?: string;
  onSelect: (icon: string) => void;
}

export const AestheticStickerSelector: React.FC<AestheticStickerSelectorProps> = ({
  selectedIcon,
  onSelect,
}) => {
  return (
    <div id="sticker-selector-container" className="space-y-2">
      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
        Chọn Sticker / Icon Xinh
      </label>
      <div className="grid grid-cols-8 sm:grid-cols-12 gap-1.5 p-2 bg-stone-50 border border-stone-200/80 rounded-xl max-h-32 overflow-y-auto">
        {CUTE_STICKERS.map((sticker, idx) => {
          const isSelected = selectedIcon === sticker;
          return (
            <button
              key={idx}
              type="button"
              id={`sticker-btn-${idx}`}
              onClick={() => onSelect(sticker)}
              className={`text-xl p-1.5 rounded-lg flex items-center justify-center transition-all ${
                isSelected
                  ? 'bg-white shadow-sm ring-2 ring-pink-400 scale-110'
                  : 'hover:bg-white/80 hover:scale-105'
              }`}
            >
              {sticker}
            </button>
          );
        })}
      </div>
    </div>
  );
};
