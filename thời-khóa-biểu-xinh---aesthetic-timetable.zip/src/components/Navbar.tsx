import React, { useState } from 'react';
import { ThemeConfig, TimetableMeta, SupabaseConfig, SyncStatusState, WorkspaceId } from '../types';
import { THEMES, WORKSPACES } from '../constants/scheduleConfig';
import {
  Sparkles,
  Palette,
  Database,
  Printer,
  RotateCcw,
  Search,
  Eye,
  EyeOff,
  Sun,
  Sunset,
  Moon,
  Calendar,
  Layers,
  Edit2,
  Check,
  RefreshCw,
  Cloud,
  Users,
  Download,
  Lock,
} from 'lucide-react';

interface NavbarProps {
  meta: TimetableMeta;
  onUpdateMeta: (meta: Partial<TimetableMeta>) => void;
  currentTheme: ThemeConfig;
  onSelectTheme: (themeId: string) => void;
  supabaseConfig: SupabaseConfig;
  syncStatus?: SyncStatusState;
  onOpenSupabaseModal: () => void;
  onFillSampleData: () => void;
  onResetData: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onPrint: () => void;
  currentWorkspace: WorkspaceId;
  onSelectWorkspace: (workspace: WorkspaceId) => void;
  onSyncAllFromOther?: () => void;
  isReadOnly?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  meta,
  onUpdateMeta,
  currentTheme,
  onSelectTheme,
  supabaseConfig,
  syncStatus = 'idle',
  onOpenSupabaseModal,
  onFillSampleData,
  onResetData,
  searchQuery,
  onSearchChange,
  onPrint,
  currentWorkspace,
  onSelectWorkspace,
  onSyncAllFromOther,
  isReadOnly = false,
}) => {
  const [isEditingHeader, setIsEditingHeader] = useState(false);
  const [tempTitle, setTempTitle] = useState(meta.title);
  const [tempSubtitle, setTempSubtitle] = useState(meta.subtitle);
  const [showThemeMenu, setShowThemeMenu] = useState(false);

  const activeWorkspaceProfile = WORKSPACES[currentWorkspace];
  const otherWorkspaceId: WorkspaceId = currentWorkspace === 'lan_vy' ? 'kim_anh' : 'lan_vy';
  const otherWorkspaceProfile = WORKSPACES[otherWorkspaceId];

  const handleSaveHeader = () => {
    onUpdateMeta({
      title: tempTitle.trim() || 'Thời Khóa Biểu Xinh 🌷',
      subtitle: tempSubtitle.trim() || 'Mỗi ngày là một bước tiến nhỏ dịu dàng ✨',
    });
    setIsEditingHeader(false);
  };

  return (
    <header className="space-y-4 no-print">
      {/* Top Bar: Workspace Switcher & Cloud Status */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-2 bg-white/80 backdrop-blur-md rounded-2xl border border-stone-200/80 shadow-xs">
        {/* Workspace Switcher */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-xs font-bold text-slate-500 px-2">
            <Users size={15} className="text-pink-500" />
            <span className="hidden sm:inline">Không gian:</span>
          </div>
          <div className="flex items-center p-1 bg-stone-100 rounded-xl gap-1">
            {(['lan_vy', 'kim_anh'] as WorkspaceId[]).map((wsId) => {
              const ws = WORKSPACES[wsId];
              const isSelected = currentWorkspace === wsId;
              return (
                <button
                  key={wsId}
                  type="button"
                  id={`workspace-tab-${wsId}`}
                  onClick={() => onSelectWorkspace(wsId)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                    isSelected
                      ? 'bg-white text-slate-800 shadow-xs scale-102 ring-1 ring-black/5'
                      : 'text-slate-500 hover:text-slate-800 hover:bg-white/50'
                  }`}
                >
                  <span className="text-sm">{ws.avatar}</span>
                  <span>{ws.name}</span>
                </button>
              );
            })}
          </div>

          {isReadOnly && (
            <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-[11px] font-semibold">
              <Lock size={12} className="text-amber-600" />
              <span>Chỉ xem (Read-only)</span>
            </div>
          )}
        </div>

        {/* Sync on demand: Copy Entire Schedule to My Workspace */}
        <div className="flex items-center gap-2">
          {isReadOnly && onSyncAllFromOther && (
            <button
              type="button"
              id="sync-all-schedule-btn"
              onClick={onSyncAllFromOther}
              title={`Sao chép toàn bộ thời khóa biểu của ${activeWorkspaceProfile.name} sang ${otherWorkspaceProfile.name}`}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all hover:scale-102 active:scale-98"
            >
              <Download size={13} />
              <span>Chép toàn bộ TKB sang lịch của tôi</span>
            </button>
          )}

          {/* Supabase Connection Button */}
          <button
            type="button"
            id="open-supabase-modal-btn"
            onClick={onOpenSupabaseModal}
            title={
              supabaseConfig.connected
                ? `Supabase đang hoạt động (${supabaseConfig.isFromEnv ? 'Cấu hình từ Vercel' : 'Cấu hình trực tiếp'})`
                : 'Bấm để cấu hình cơ sở dữ liệu Supabase'
            }
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-2 shadow-xs ${
              supabaseConfig.connected
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                : 'bg-white text-slate-700 border-stone-200 hover:border-emerald-300'
            }`}
          >
            {syncStatus === 'syncing' ? (
              <RefreshCw size={14} className="text-emerald-600 animate-spin" />
            ) : (
              <Database size={14} className={supabaseConfig.connected ? 'text-emerald-600' : 'text-slate-400'} />
            )}
            <span className="hidden sm:inline">
              {syncStatus === 'syncing'
                ? 'Đang lưu...'
                : supabaseConfig.connected
                ? supabaseConfig.isFromEnv
                  ? 'Cloud Synced'
                  : 'Supabase DB'
                : 'Cơ sở dữ liệu'}
            </span>
            <span
              className={`w-2 h-2 rounded-full ${
                supabaseConfig.connected
                  ? syncStatus === 'syncing'
                    ? 'bg-amber-500 animate-ping'
                    : 'bg-emerald-500 animate-pulse'
                  : 'bg-amber-400'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Main Banner with Title & Quick Controls */}
      <div
        className={`p-5 sm:p-7 rounded-3xl ${currentTheme.headerBg} border ${currentTheme.borderColor} shadow-xs relative overflow-hidden transition-all`}
      >
        {/* Decorative background circles */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-pink-300/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-48 h-48 bg-amber-200/15 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Title & Subtitle */}
          <div className="space-y-1">
            {isEditingHeader && !isReadOnly ? (
              <div className="space-y-2 max-w-md">
                <input
                  type="text"
                  value={tempTitle}
                  onChange={(e) => setTempTitle(e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-pink-300 rounded-xl text-lg font-bold text-slate-800 focus:outline-none"
                  placeholder="Nhập tiêu đề thời khóa biểu..."
                />
                <input
                  type="text"
                  value={tempSubtitle}
                  onChange={(e) => setTempSubtitle(e.target.value)}
                  className="w-full px-3 py-1 bg-white border border-pink-200 rounded-lg text-xs text-slate-600 focus:outline-none"
                  placeholder="Nhập câu quote truyền cảm hứng..."
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleSaveHeader}
                    className="px-3 py-1 bg-pink-500 hover:bg-pink-600 text-white rounded-lg text-xs font-bold flex items-center gap-1"
                  >
                    <Check size={13} /> Lưu
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsEditingHeader(false)}
                    className="px-2.5 py-1 text-slate-500 text-xs font-medium"
                  >
                    Hủy
                  </button>
                </div>
              </div>
            ) : (
              <div
                onClick={() => {
                  if (!isReadOnly) {
                    setTempTitle(meta.title);
                    setTempSubtitle(meta.subtitle);
                    setIsEditingHeader(true);
                  }
                }}
                className={`group ${!isReadOnly ? 'cursor-pointer' : ''}`}
                title={!isReadOnly ? 'Bấm để chỉnh sửa tiêu đề' : undefined}
              >
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-800 tracking-tight font-display">
                    {meta.title}
                  </h1>
                  {!isReadOnly && (
                    <span className="opacity-0 group-hover:opacity-100 p-1 rounded-lg text-slate-400 hover:text-pink-600 transition-opacity">
                      <Edit2 size={15} />
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-slate-500 flex items-center gap-1.5 font-medium">
                  <span>{meta.subtitle}</span>
                  {!isReadOnly && (
                    <span className="text-[11px] text-pink-400 font-semibold">(Tùy chỉnh)</span>
                  )}
                </p>
              </div>
            )}
          </div>

          {/* Right Action Badges */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Theme Switcher Button */}
            <div className="relative">
              <button
                type="button"
                id="theme-switcher-btn"
                onClick={() => setShowThemeMenu(!showThemeMenu)}
                className="px-3.5 py-2 bg-white/80 hover:bg-white text-slate-700 rounded-2xl text-xs font-bold border border-stone-200 shadow-xs flex items-center gap-1.5 transition-all"
              >
                <Palette size={15} className="text-pink-500" />
                <span>{currentTheme.badge}</span>
              </button>

              {showThemeMenu && (
                <div
                  id="theme-dropdown-menu"
                  className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-stone-200 p-2 z-30 space-y-1"
                >
                  <span className="block px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Chọn Style Canva
                  </span>
                  {THEMES.map((th) => (
                    <button
                      key={th.id}
                      type="button"
                      onClick={() => {
                        onSelectTheme(th.id);
                        setShowThemeMenu(false);
                      }}
                      className={`w-full px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
                        th.id === currentTheme.id
                          ? 'bg-pink-50 text-pink-700 font-bold'
                          : 'text-slate-700 hover:bg-stone-50'
                      }`}
                    >
                      <span>{th.badge}</span>
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-stone-300"
                        style={{ backgroundColor: th.accentColor }}
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Fill Sample Data (Only enabled in owner mode) */}
            {!isReadOnly && (
              <button
                type="button"
                id="fill-sample-btn"
                onClick={onFillSampleData}
                title="Điền thời khóa biểu mẫu có sẵn"
                className="px-3.5 py-2 bg-white/80 hover:bg-pink-50 text-pink-700 rounded-2xl text-xs font-bold border border-pink-200 shadow-xs flex items-center gap-1.5 transition-all"
              >
                <Sparkles size={14} className="text-pink-500" />
                <span>Mẫu Xịn</span>
              </button>
            )}

            {/* Print / PDF Button */}
            <button
              type="button"
              id="print-btn"
              onClick={onPrint}
              className="px-3.5 py-2 bg-stone-800 hover:bg-black text-white rounded-2xl text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all"
            >
              <Printer size={14} />
              <span>In / Lưu PDF</span>
            </button>
          </div>
        </div>
      </div>

      {/* Control Bar: View Modes, Search, and Breaks Toggle */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 p-2 bg-white/70 backdrop-blur-xs rounded-2xl border border-stone-200/80 shadow-xs">
        {/* Session / View Mode Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 lg:pb-0">
          {[
            { id: 'full', label: 'Cả Ngày', icon: <Layers size={13} /> },
            { id: 'morning', label: 'Sáng (5 Tiết)', icon: <Sun size={13} className="text-amber-500" /> },
            { id: 'afternoon', label: 'Chiều (Tiết 6-9)', icon: <Sunset size={13} className="text-orange-500" /> },
            { id: 'evening', label: 'Tối (17h-20h30)', icon: <Moon size={13} className="text-indigo-500" /> },
            { id: 'daily', label: 'Xem Theo Ngày', icon: <Calendar size={13} className="text-pink-500" /> },
          ].map((mode) => (
            <button
              key={mode.id}
              type="button"
              id={`filter-mode-${mode.id}`}
              onClick={() => onUpdateMeta({ viewMode: mode.id as any })}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition-all ${
                meta.viewMode === mode.id
                  ? 'bg-pink-500 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-stone-100 hover:text-slate-900'
              }`}
            >
              {mode.icon}
              <span>{mode.label}</span>
            </button>
          ))}
        </div>

        {/* Search and Secondary Controls */}
        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
          {/* Search Box */}
          <div className="relative flex-1 sm:w-48">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              id="search-input"
              placeholder="Tìm môn, phòng, thầy cô..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-stone-100/80 border border-stone-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-300"
            />
          </div>

          {/* Toggle Breaks */}
          {meta.viewMode !== 'daily' && (
            <button
              type="button"
              id="toggle-breaks-btn"
              onClick={() => onUpdateMeta({ showBreaks: !meta.showBreaks })}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                meta.showBreaks
                  ? 'bg-amber-50 text-amber-800 border-amber-200'
                  : 'bg-stone-100 text-slate-500 border-stone-200'
              }`}
              title="Hiện hoặc ẩn các thanh giờ ra chơi 5p / 15p"
            >
              {meta.showBreaks ? <Eye size={13} /> : <EyeOff size={13} />}
              <span>{meta.showBreaks ? 'Hiện giờ ra chơi' : 'Ẩn giờ ra chơi'}</span>
            </button>
          )}

          {/* Reset All button (Only in owner mode) */}
          {!isReadOnly && (
            <button
              type="button"
              id="reset-all-btn"
              onClick={onResetData}
              title="Xóa trắng bảng thời khóa biểu"
              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
            >
              <RotateCcw size={15} />
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
