import React, { useState, useEffect } from 'react';
import { TimetableEntry, DayOfWeek, WorkspaceId } from '../types';
import { DAYS_OF_WEEK, PERIODS, COLOR_PALETTES } from '../constants/scheduleConfig';
import { AestheticStickerSelector } from './AestheticStickerSelector';
import { X, Trash2, Check, Sparkles, MapPin, User, FileText } from 'lucide-react';

interface EditEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (entry: TimetableEntry) => void;
  onDelete?: (id: string) => void;
  initialEntry?: Partial<TimetableEntry> | null;
  defaultDay?: DayOfWeek;
  defaultPeriodId?: string;
  currentWorkspace?: WorkspaceId;
}

const QUICK_SUBJECT_SUGGESTIONS = [
  'Toán Cao Cấp',
  'Tiếng Anh IELTS',
  'Lập Trình Web React',
  'Thiết Kế Canva',
  'Văn Học',
  'Xác Suất Thống Kê',
  'Quản Trị Dự Án',
  'Cơ Sở Dữ Liệu SQL',
  'Tự Học & Ôn Tập',
  'Thể Dục / Yoga',
  'Học Tiếng Hàn',
  'Đọc Sách & Me-time',
];

export const EditEntryModal: React.FC<EditEntryModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  initialEntry,
  defaultDay = 'mon',
  defaultPeriodId = 'm1',
  currentWorkspace = 'lan_vy',
}) => {
  const [day, setDay] = useState<DayOfWeek>(defaultDay);
  const [periodId, setPeriodId] = useState<string>(defaultPeriodId);
  const [subject, setSubject] = useState<string>('');
  const [room, setRoom] = useState<string>('');
  const [teacher, setTeacher] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [colorTheme, setColorTheme] = useState<string>('pink');
  const [icon, setIcon] = useState<string>('🌸');
  const [status, setStatus] = useState<'todo' | 'in_progress' | 'done'>('todo');

  useEffect(() => {
    if (initialEntry) {
      setDay(initialEntry.day || defaultDay);
      setPeriodId(initialEntry.periodId || defaultPeriodId);
      setSubject(initialEntry.subject || '');
      setRoom(initialEntry.room || '');
      setTeacher(initialEntry.teacher || '');
      setNotes(initialEntry.notes || '');
      setColorTheme(initialEntry.colorTheme || 'pink');
      setIcon(initialEntry.icon || '🌸');
      setStatus(initialEntry.status || 'todo');
    } else {
      setDay(defaultDay);
      setPeriodId(defaultPeriodId);
      setSubject('');
      setRoom('');
      setTeacher('');
      setNotes('');
      setColorTheme('pink');
      setIcon('🌸');
      setStatus('todo');
    }
  }, [initialEntry, defaultDay, defaultPeriodId, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim()) return;

    const entryToSave: TimetableEntry = {
      id: initialEntry?.id || `${currentWorkspace}_${day}_${periodId}_${Math.random().toString(36).substr(2, 4)}`,
      workspaceId: initialEntry?.workspaceId || currentWorkspace,
      day,
      periodId,
      subject: subject.trim(),
      room: room.trim(),
      teacher: teacher.trim(),
      notes: notes.trim(),
      colorTheme,
      icon,
      status,
      updatedAt: new Date().toISOString(),
    };

    onSave(entryToSave);
    onClose();
  };

  const selectedPeriod = PERIODS.find((p) => p.id === periodId);

  return (
    <div
      id="edit-entry-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs transition-opacity overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="edit-entry-modal-content"
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-stone-200/80 p-6 sm:p-7 my-8 transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-stone-100">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl p-2 bg-pink-50 rounded-2xl border border-pink-100/80">
              {icon}
            </span>
            <div>
              <h3 className="text-lg font-bold text-slate-800 font-display">
                {initialEntry?.id ? 'Chỉnh Sửa Tiết Học' : 'Thêm Tiết Học Mới'}
              </h3>
              <p className="text-xs text-slate-500">
                Tùy biến phong cách Canva xinh xắn và tinh tế
              </p>
            </div>
          </div>
          <button
            id="close-edit-modal-btn"
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          {/* Day & Period selectors */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                Ngày trong tuần
              </label>
              <select
                id="select-entry-day"
                value={day}
                onChange={(e) => setDay(e.target.value as DayOfWeek)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-pink-300"
              >
                {DAYS_OF_WEEK.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.shortName})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                Khung giờ tiết học
              </label>
              <select
                id="select-entry-period"
                value={periodId}
                onChange={(e) => setPeriodId(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-pink-300"
              >
                {PERIODS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.startTime} - {p.endTime})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {selectedPeriod && (
            <div className="px-3 py-1.5 bg-amber-50/70 border border-amber-100 rounded-lg text-xs text-amber-700 flex items-center gap-1.5">
              <span>⏰</span>
              <span>
                {selectedPeriod.name}: <strong>{selectedPeriod.startTime} - {selectedPeriod.endTime}</strong> ({selectedPeriod.durationMinutes} phút)
              </span>
            </div>
          )}

          {/* Subject name */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
              Tên Môn Học / Hoạt Động *
            </label>
            <input
              id="input-entry-subject"
              type="text"
              required
              placeholder="VD: Toán Cao Cấp, Tiếng Anh, Canva Design..."
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-pink-300"
            />
            {/* Quick suggestions */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {QUICK_SUBJECT_SUGGESTIONS.slice(0, 6).map((sug) => (
                <button
                  key={sug}
                  type="button"
                  onClick={() => setSubject(sug)}
                  className="text-[11px] px-2 py-0.5 bg-stone-100 hover:bg-pink-100 hover:text-pink-700 text-slate-600 rounded-md transition-colors"
                >
                  +{sug}
                </button>
              ))}
            </div>
          </div>

          {/* Room and Teacher */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                <MapPin size={13} /> Phòng / Nơi học
              </label>
              <input
                id="input-entry-room"
                type="text"
                placeholder="VD: Phòng A203, Online Meet..."
                value={room}
                onChange={(e) => setRoom(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-pink-300"
              />
            </div>
            <div>
              <label className="flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                <User size={13} /> Giảng viên / Người hướng dẫn
              </label>
              <input
                id="input-entry-teacher"
                type="text"
                placeholder="VD: Cô Thuỳ Trang, Thầy David..."
                value={teacher}
                onChange={(e) => setTeacher(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-pink-300"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
              <FileText size={13} /> Ghi chú & Bài tập
            </label>
            <input
              id="input-entry-notes"
              type="text"
              placeholder="VD: Chuẩn bị bài tập số 4, mang theo laptop..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-pink-300"
            />
          </div>

          {/* Color palette selector */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
              Gam Màu Thẻ (Aesthetic Pastel Palette)
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
              {COLOR_PALETTES.map((palette) => {
                const isSelected = colorTheme === palette.id;
                return (
                  <button
                    key={palette.id}
                    type="button"
                    id={`palette-btn-${palette.id}`}
                    onClick={() => setColorTheme(palette.id)}
                    className={`flex flex-col items-center p-2 rounded-xl border text-[11px] font-medium transition-all ${
                      palette.bg
                    } ${palette.border} ${
                      isSelected ? 'ring-2 ring-pink-500 shadow-sm scale-105 font-bold' : 'opacity-80 hover:opacity-100'
                    }`}
                  >
                    <span
                      className="w-4 h-4 rounded-full mb-1 shadow-xs"
                      style={{ backgroundColor: palette.dot }}
                    />
                    <span className={palette.text}>{palette.name.split(' ')[0]}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sticker / Icon selector */}
          <AestheticStickerSelector selectedIcon={icon} onSelect={(newIcon) => setIcon(newIcon)} />

          {/* Study Status */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
              Trạng thái hoàn thành
            </label>
            <div className="flex gap-2">
              {[
                { id: 'todo', label: 'Chưa học', icon: '⏳' },
                { id: 'in_progress', label: 'Đang học', icon: '📖' },
                { id: 'done', label: 'Đã hoàn thành', icon: '✅' },
              ].map((st) => (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => setStatus(st.id as any)}
                  className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-medium border flex items-center justify-center gap-1.5 transition-all ${
                    status === st.id
                      ? 'bg-pink-50 border-pink-300 text-pink-700 font-semibold'
                      : 'bg-stone-50 border-stone-200 text-slate-600 hover:bg-stone-100'
                  }`}
                >
                  <span>{st.icon}</span>
                  <span>{st.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-between pt-3 border-t border-stone-100">
            {initialEntry?.id && onDelete ? (
              <button
                type="button"
                id="delete-entry-btn"
                onClick={() => {
                  if (window.confirm('Bạn có chắc muốn xóa tiết học này không?')) {
                    onDelete(initialEntry.id!);
                    onClose();
                  }
                }}
                className="px-3.5 py-2 text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Trash2 size={14} />
                Xóa tiết
              </button>
            ) : (
              <div />
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                id="cancel-entry-btn"
                onClick={onClose}
                className="px-4 py-2 text-slate-600 hover:bg-stone-100 rounded-xl text-xs font-semibold transition-colors"
              >
                Hủy
              </button>
              <button
                type="submit"
                id="save-entry-btn"
                className="px-5 py-2.5 bg-gradient-to-r from-pink-400 to-rose-400 hover:from-pink-500 hover:to-rose-500 text-white rounded-xl text-xs font-bold shadow-md shadow-pink-200 flex items-center gap-1.5 transition-all active:scale-95"
              >
                <Check size={15} />
                Lưu Tiết Học
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
