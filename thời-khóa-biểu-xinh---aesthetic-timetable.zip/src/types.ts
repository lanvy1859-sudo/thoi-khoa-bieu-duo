export type DayOfWeek = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';

export type SessionPeriodType = 'morning' | 'afternoon' | 'evening';

export type WorkspaceId = 'lan_vy' | 'kim_anh';

export interface WorkspaceProfile {
  id: WorkspaceId;
  name: string; // 'Lan Vy' | 'Kim Ánh'
  displayName: string;
  avatar: string; // '🌸' | '✨'
  badgeColor: string;
  defaultTitle: string;
  defaultSubtitle: string;
  defaultThemeId: string;
}

export interface PeriodDefinition {
  id: string; // e.g. 'm1', 'm2', 'a1', 'e1'
  name: string; // e.g. 'Tiết 1'
  session: SessionPeriodType;
  startTime: string; // '07:00'
  endTime: string; // '07:45'
  durationMinutes: number; // 45
  breakAfterMinutes?: number; // 5 or 15
  breakLabel?: string; // 'Ra chơi 5p' or 'Ra chơi lớn 15p'
  isBreak?: boolean;
}

export interface TimetableEntry {
  id: string;
  workspaceId: WorkspaceId;
  day: DayOfWeek;
  periodId: string;
  subject: string;
  room?: string;
  teacher?: string;
  notes?: string;
  colorTheme: string; // e.g., 'pink', 'sage', 'lavender', 'peach', 'amber', 'sky'
  icon?: string; // emoji or sticker e.g. '🌸', '📚', '☕'
  status?: 'todo' | 'in_progress' | 'done';
  updatedAt?: string;
}

export interface TimetableMeta {
  workspaceId?: WorkspaceId;
  title: string;
  subtitle: string;
  ownerName: string;
  academicYear: string;
  themeId: string;
  showBreaks: boolean;
  viewMode: 'full' | 'morning' | 'afternoon' | 'evening' | 'daily';
  selectedDailyDay: DayOfWeek;
}

export interface ThemeConfig {
  id: string;
  name: string;
  badge: string;
  bgColor: string;
  cardBg: string;
  borderColor: string;
  accentColor: string;
  textColor: string;
  subtextColor: string;
  headerBg: string;
  dayHeaderBg: string;
  glowEffect: string;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  tableName: string;
  connected: boolean;
  lastSyncedAt?: string;
  isFromEnv?: boolean;
}

export type SyncStatusState = 'idle' | 'syncing' | 'synced' | 'error' | 'local';
